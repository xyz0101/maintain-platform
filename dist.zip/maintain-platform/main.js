(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var routes = [];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "body{\r\n     background-color:#f0f2f5;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7S0FDSyx5QkFBeUI7Q0FDN0IiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbImJvZHl7XHJcbiAgICAgYmFja2dyb3VuZC1jb2xvcjojZjBmMmY1O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n<div style=\"background-color:#f0f2f5;height:100%\">\r\n<app-nav></app-nav>\r\n<router-outlet></router-outlet>\r\n<app-footer></app-footer>\r\n\r\n</div>\r\n "

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_interceptor_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/interceptor-service.service */ "./src/app/interceptor-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AppComponent = /** @class */ (function () {
    function AppComponent(interceptorService) {
        this.interceptorService = interceptorService;
        this.title = 'HR-运维平台';
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.interceptorService.getAuth().subscribe(function (res) {
            if (!(res.code == "200" && res.data != null && res.data != "null")) {
                _this.interceptorService.gotoLogin();
            }
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_interceptor_service_service__WEBPACK_IMPORTED_MODULE_1__["InterceptorServiceService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _nav_nav_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./nav/nav.component */ "./src/app/nav/nav.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _content_content_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./content/content.component */ "./src/app/content/content.component.ts");
/* harmony import */ var _eval_maintain_eval_maintain_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./eval-maintain/eval-maintain.component */ "./src/app/eval-maintain/eval-maintain.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var ngx_loading__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-loading */ "./node_modules/ngx-loading/fesm5/ngx-loading.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_locales_en__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common/locales/en */ "./node_modules/@angular/common/locales/en.js");
/* harmony import */ var _angular_common_locales_en__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_en__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common/locales/zh */ "./node_modules/@angular/common/locales/zh.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _eval_data_ready_eval_data_ready_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./eval-data-ready/eval-data-ready.component */ "./src/app/eval-data-ready/eval-data-ready.component.ts");
/* harmony import */ var _eval_data_ready_sub_ready_step_second_ready_step_second_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./eval-data-ready-sub/ready-step-second/ready-step-second.component */ "./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.ts");
/* harmony import */ var _eval_data_ready_sub_ready_step_one_ready_step_one_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./eval-data-ready-sub/ready-step-one/ready-step-one.component */ "./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.ts");
/* harmony import */ var _eval_data_ready_sub_ready_step_third_ready_step_third_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./eval-data-ready-sub/ready-step-third/ready-step-third.component */ "./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.ts");
/* harmony import */ var src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/guard/RouterGuard */ "./src/app/guard/RouterGuard.ts");
/* harmony import */ var _eval_data_ready_sub_ready_step_fourth_ready_step_fourth_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component */ "./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.ts");
/* harmony import */ var _eval_data_ready_sub_ready_step_fifth_ready_step_fifth_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component */ "./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.ts");
/* harmony import */ var src_app_interceptor_service_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/interceptor-service.service */ "./src/app/interceptor-service.service.ts");
/* harmony import */ var _target_target_maintain_target_maintain_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./target/target-maintain/target-maintain.component */ "./src/app/target/target-maintain/target-maintain.component.ts");
/* harmony import */ var _target_target_self_date_maintain_target_self_date_maintain_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./target/target-self-date-maintain/target-self-date-maintain.component */ "./src/app/target/target-self-date-maintain/target-self-date-maintain.component.ts");
/* harmony import */ var _target_target_self_todo_target_self_todo_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./target/target-self-todo/target-self-todo.component */ "./src/app/target/target-self-todo/target-self-todo.component.ts");
/* harmony import */ var _salary_salary_maintain_salary_maintain_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./salary/salary-maintain/salary-maintain.component */ "./src/app/salary/salary-maintain/salary-maintain.component.ts");
/* harmony import */ var _salary_salary_special_config_salary_special_config_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./salary/salary-special-config/salary-special-config.component */ "./src/app/salary/salary-special-config/salary-special-config.component.ts");
/* harmony import */ var _salary_salary_holiday_config_salary_holiday_config_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./salary/salary-holiday-config/salary-holiday-config.component */ "./src/app/salary/salary-holiday-config/salary-holiday-config.component.ts");
/* harmony import */ var _no_auth_page_no_auth_page_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./no-auth-page/no-auth-page.component */ "./src/app/no-auth-page/no-auth-page.component.ts");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var src_app_target_service_target_service__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! src/app/target-service/target.service */ "./src/app/target-service/target.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





































Object(_angular_common__WEBPACK_IMPORTED_MODULE_15__["registerLocaleData"])(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_17___default.a);
Object(_angular_common__WEBPACK_IMPORTED_MODULE_15__["registerLocaleData"])(_angular_common_locales_en__WEBPACK_IMPORTED_MODULE_16___default.a);
var routerConfig = [
    { path: 'home', component: _eval_maintain_eval_maintain_component__WEBPACK_IMPORTED_MODULE_8__["EvalMaintainComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'eval/first/:curPage', component: _eval_maintain_eval_maintain_component__WEBPACK_IMPORTED_MODULE_8__["EvalMaintainComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'target/selfdate', component: _target_target_self_date_maintain_target_self_date_maintain_component__WEBPACK_IMPORTED_MODULE_27__["TargetSelfDateMaintainComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'target/selfTodo', component: _target_target_self_todo_target_self_todo_component__WEBPACK_IMPORTED_MODULE_28__["TargetSelfTodoComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'eval/ready', component: _eval_data_ready_eval_data_ready_component__WEBPACK_IMPORTED_MODULE_18__["EvalDataReadyComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]], children: [
            { path: '', component: _eval_data_ready_sub_ready_step_one_ready_step_one_component__WEBPACK_IMPORTED_MODULE_20__["ReadyStepOneComponent"], canDeactivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
            { path: 'stepsecond', component: _eval_data_ready_sub_ready_step_second_ready_step_second_component__WEBPACK_IMPORTED_MODULE_19__["ReadyStepSecondComponent"], canDeactivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
            { path: 'stepthird', component: _eval_data_ready_sub_ready_step_third_ready_step_third_component__WEBPACK_IMPORTED_MODULE_21__["ReadyStepThirdComponent"], canDeactivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
            { path: 'stepfourth', component: _eval_data_ready_sub_ready_step_fourth_ready_step_fourth_component__WEBPACK_IMPORTED_MODULE_23__["ReadyStepFourthComponent"], canDeactivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
            { path: 'stepfifth', component: _eval_data_ready_sub_ready_step_fifth_ready_step_fifth_component__WEBPACK_IMPORTED_MODULE_24__["ReadyStepFifthComponent"], canDeactivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] }
        ], canDeactivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'salary/special', component: _salary_salary_special_config_salary_special_config_component__WEBPACK_IMPORTED_MODULE_30__["SalarySpecialConfigComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'salary/holiday', component: _salary_salary_holiday_config_salary_holiday_config_component__WEBPACK_IMPORTED_MODULE_31__["SalaryHolidayConfigComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] },
    { path: 'noauth', component: _no_auth_page_no_auth_page_component__WEBPACK_IMPORTED_MODULE_32__["NoAuthPageComponent"], canActivate: [src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"]] }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _nav_nav_component__WEBPACK_IMPORTED_MODULE_5__["NavComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_6__["FooterComponent"],
                _content_content_component__WEBPACK_IMPORTED_MODULE_7__["ContentComponent"],
                _eval_maintain_eval_maintain_component__WEBPACK_IMPORTED_MODULE_8__["EvalMaintainComponent"],
                _eval_data_ready_eval_data_ready_component__WEBPACK_IMPORTED_MODULE_18__["EvalDataReadyComponent"],
                _eval_data_ready_sub_ready_step_second_ready_step_second_component__WEBPACK_IMPORTED_MODULE_19__["ReadyStepSecondComponent"],
                _eval_data_ready_sub_ready_step_one_ready_step_one_component__WEBPACK_IMPORTED_MODULE_20__["ReadyStepOneComponent"],
                _eval_data_ready_sub_ready_step_third_ready_step_third_component__WEBPACK_IMPORTED_MODULE_21__["ReadyStepThirdComponent"],
                _eval_data_ready_sub_ready_step_fourth_ready_step_fourth_component__WEBPACK_IMPORTED_MODULE_23__["ReadyStepFourthComponent"],
                _eval_data_ready_sub_ready_step_fifth_ready_step_fifth_component__WEBPACK_IMPORTED_MODULE_24__["ReadyStepFifthComponent"],
                _target_target_maintain_target_maintain_component__WEBPACK_IMPORTED_MODULE_26__["TargetMaintainComponent"],
                _target_target_self_date_maintain_target_self_date_maintain_component__WEBPACK_IMPORTED_MODULE_27__["TargetSelfDateMaintainComponent"],
                _target_target_self_todo_target_self_todo_component__WEBPACK_IMPORTED_MODULE_28__["TargetSelfTodoComponent"],
                _salary_salary_maintain_salary_maintain_component__WEBPACK_IMPORTED_MODULE_29__["SalaryMaintainComponent"],
                _salary_salary_special_config_salary_special_config_component__WEBPACK_IMPORTED_MODULE_30__["SalarySpecialConfigComponent"],
                _salary_salary_holiday_config_salary_holiday_config_component__WEBPACK_IMPORTED_MODULE_31__["SalaryHolidayConfigComponent"],
                _no_auth_page_no_auth_page_component__WEBPACK_IMPORTED_MODULE_32__["NoAuthPageComponent"],
                _salary_salary_maintain_salary_maintain_component__WEBPACK_IMPORTED_MODULE_29__["SalaryMaintainComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                ngx_loading__WEBPACK_IMPORTED_MODULE_13__["NgxLoadingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ReactiveFormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_10__["HttpModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_10__["JsonpModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_9__["RouterModule"].forRoot(routerConfig, { useHash: true, onSameUrlNavigation: 'reload' }),
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__["BrowserAnimationsModule"],
                ng_zorro_antd__WEBPACK_IMPORTED_MODULE_14__["NgZorroAntdModule"]
            ],
            providers: [{ provide: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_14__["NZ_I18N"], useValue: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_14__["zh_CN"] }, src_app_guard_RouterGuard__WEBPACK_IMPORTED_MODULE_22__["RouterGuard"], { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HTTP_INTERCEPTORS"], useClass: src_app_interceptor_service_service__WEBPACK_IMPORTED_MODULE_25__["InterceptorServiceService"], multi: true }, {
                    provide: _angular_common__WEBPACK_IMPORTED_MODULE_15__["LocationStrategy"],
                    useClass: _angular_common__WEBPACK_IMPORTED_MODULE_15__["HashLocationStrategy"]
                }, src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_33__["EvalServiceService"], src_app_target_service_target_service__WEBPACK_IMPORTED_MODULE_34__["TargetService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/comps/MyComponent.ts":
/*!**************************************!*\
  !*** ./src/app/comps/MyComponent.ts ***!
  \**************************************/
/*! exports provided: MyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyComponent", function() { return MyComponent; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var MyComponent = /** @class */ (function () {
    //注入路由信息,以及评价的服务
    function MyComponent(routerInfo, evalService, fb, modalService, msg) {
        var _this = this;
        this.routerInfo = routerInfo;
        this.evalService = evalService;
        this.fb = fb;
        this.modalService = modalService;
        this.msg = msg;
        //延迟时间
        this.timeOutNum = 300;
        //输入员工的自动提示
        this.options = [];
        //当前页码
        this.curPage = 1;
        //缓存的当前列表的map
        this.curList = new Array();
        //修改过的数据的map
        this.updateMap = new Map();
        //修改过的数据的集合
        this.updateList = [];
        //前端添加的集合
        this.addUIList = [];
        //需要向后端删除的集合
        this.deleteList = [];
        //对话框是否可见
        this.isUpdataShow = false;
        //是否正在确认
        this.isOkLoading = false;
        //已修改的数据的当前页
        this.updateCurPage = 1;
        //搜索的字段
        this.searchFields = new Map();
        //搜索条件json串
        this.searchJson = "{'null':null}";
        //条件元素列表
        this.controlArray = [];
        //是否展开
        this.isCollapse = true;
        //职等下拉列表
        this.empLevelList = [];
        //搜索条件默认展示多少个 ，默认值3
        this.searchFieldsLimitForRow = 3;
        //排序条件
        this.sortValue = null;
        this.sortKey = null;
        this.fileList = [];
        this.customReq = function (item) {
            // 始终返回一个 `Subscription` 对象，nz-upload 会在适当时机自动取消订阅
            return _this.evalService.uploadExcel(item).subscribe(function (event) {
                if (event.type === _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress) {
                    if (event.total > 0) {
                        // tslint:disable-next-line:no-any
                        event.percent = event.loaded / event.total * 100;
                    }
                    // 处理上传进度条，必须指定 `percent` 属性来表示进度
                    item.onProgress(event, item.file);
                }
                else if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpResponse"]) {
                    // 处理成功
                    item.onSuccess(event.body, item.file, event);
                    _this.successUpload();
                }
            }, function (err) {
                // 处理失败
                item.onError(err, item.file);
                _this.errorUpload();
            });
        };
    }
    MyComponent.prototype.errorUpload = function () {
        throw new Error("Method not implemented.");
    };
    MyComponent.prototype.successUpload = function () {
        throw new Error("Method not implemented.");
    };
    MyComponent.prototype.setSearchFieldsLimitForRow = function (value) {
        this.searchFieldsLimitForRow = value;
    };
    /**
     * 初始化表格
     */
    MyComponent.prototype.initTable = function (dataSource) {
        // 初始化数据源
        this.dataSource = dataSource;
        // 获取路由信息中的订阅参数
        this.routerInfo.params.subscribe(function (params) {
            // 获取页码
            //  this.curPage=params["curPage"];
        });
        // 加载数据
        this.loadEvalByPage(this.curPage + '');
    };
    /**
     * 初始化搜索
     */
    MyComponent.prototype.initSearch = function () {
        // 初始化搜索字段
        this.initSearchFields();
        // 构建表单
        this.construtSearch();
    };
    /**
      * 从服务器端获取数据
      * @param curPage
      */
    MyComponent.prototype.loadEvalByPage = function (curPage) {
        if (curPage == null) {
            this.curPage = 1;
        }
        else {
            this.curPage = parseInt(curPage);
        }
        console.log(curPage);
        // 置空当前数据集合
        this.curList = this.curList.filter(function (d) { return d == null; });
        // 加载数据
        this.loadData();
        console.log('当前集合');
        console.log(this.curList);
    };
    /**
     * 取消
     */
    MyComponent.prototype.cancelUpdate = function () {
        this.isUpdataShow = false;
    };
    /**
     * 确认
     */
    MyComponent.prototype.okUpdate = function () {
        var _this = this;
        this.isOkLoading = true;
        //处理确认
        this.evalService.updateEval(JSON.stringify(this.updateList)).subscribe(function (val) {
            _this.success(null);
            _this.completedUpdate();
        }, function (response) {
            _this.error(null);
            _this.completedUpdate();
        });
    };
    /**
     * 展示修改对话框
     */
    MyComponent.prototype.showUpdateDialog = function () {
        this.isUpdataShow = true;
    };
    //展开高级搜索 ，默认显示三个
    MyComponent.prototype.toggleCollapse = function () {
        var _this = this;
        this.isCollapse = !this.isCollapse;
        this.controlArray.forEach(function (c, index) {
            c.show = _this.isCollapse ? (index < _this.searchFieldsLimitForRow) : true;
        });
    };
    /**
     * 重置表单
     */
    MyComponent.prototype.resetForm = function () {
        this.validateForm.reset();
    };
    /**
     * 构建搜索表单
     */
    MyComponent.prototype.construtSearch = function () {
        var _this = this;
        this.validateForm = this.fb.group({});
        var i = 0;
        this.searchFields.forEach(function (value, key) {
            _this.controlArray.push({ index: i, show: i < _this.searchFieldsLimitForRow, val: value, field: key });
            _this.validateForm.addControl(key, new _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormControl"]());
            i++;
        });
    };
    /**
     * 初始化职等下拉列表
     */
    MyComponent.prototype.initEmpLevelList = function () {
        var children = [];
        for (var i = 1; i <= 10; i++) {
            children.push({ label: i, value: i });
        }
        this.empLevelList = children;
    };
    /**
     * 搜索按钮点击
     */
    MyComponent.prototype.searchEval = function () {
        //执行查询
        this.loadEvalByPage("1");
        console.log(JSON.stringify(this.validateForm.value));
    };
    /**
     * 排序
     * @param sort
     */
    MyComponent.prototype.sort = function (sort) {
        this.sortKey = sort.key;
        this.sortValue = sort.value;
        //执行查询
        this.loadEvalByPage(this.dataSource.dataStatus.pageInfo.curPage.toString());
        console.log(this.sortKey + "    " + this.sortValue);
    };
    /**
     * 改变数据状态
     * 按照 Angular 的设计，当需要对 nzData 中的数据进行增删时需要使用以下操作，使用 push 或者 splice 修改 nzData 的数据不会生效
     */
    MyComponent.prototype.changeStatu = function (curList, updateMap, updateList, dataStatus) {
        var _this = this;
        //需要添加延迟，在使用ngModelChange的时候变化时发生在改变数据的同时，在执行这里的饿时候数据还没有变化，所以要等待数据变化之后在比较
        window.setTimeout(function () {
            // console.log(curList)
            // console.log(dataStatus.myData )
            //遍历原始表
            for (var i = 0; i < curList.length; i++) {
                var key = JSON.stringify(curList[i]);
                //  console.log("key====》",curList[i])
                //  console.log("value====》", dataStatus.myData[i] )
                if (key != JSON.stringify(dataStatus.myData[i])) {
                    if (dataStatus.myData[i] != undefined) {
                        //   console.log("发生了变化")
                        //  console.log("key====》"+key)
                        //  console.log("value====》"+JSON.stringify (dataStatus.myData[i]))
                        updateMap.set(key, dataStatus.myData[i]);
                    }
                }
                else {
                    // console.log("变化复原")
                    // console.log("key====》"+key)
                    updateMap.delete(key);
                }
            }
            // 删除数据
            updateList = updateList.filter(function (d) { return d == null; });
            var i = 0;
            updateMap.forEach(function (value, key) {
                // 增加数据
                if (value != null && value != undefined) {
                    updateList[i] = value;
                    i++;
                }
            });
            console.log("变化的集合");
            console.log(updateList);
            console.log(_this.addUIList);
            console.log(_this.updateMap);
            _this.updateList = updateList;
        }, this.timeOutNum);
        console.log("延迟完成");
        return updateList;
    };
    MyComponent.prototype.success = function (txt) {
        this.modalService.success({
            nzTitle: '提示信息',
            nzContent: txt == null ? '修改信息成功' : txt
        });
    };
    MyComponent.prototype.error = function (txt) {
        this.modalService.error({
            nzTitle: '错误信息',
            nzContent: txt == null ? '修改信息失败' : txt
        });
    };
    /**
     * 取消已修改的数据
     */
    MyComponent.prototype.completedUpdate = function () {
        // 删除数据
        this.updateList = this.updateList.filter(function (d) { return d.employeeCode == null; });
        this.updateMap.clear();
        this.isUpdataShow = false;
        this.isOkLoading = false;
        this.loadEvalByPage(this.dataSource.dataStatus.pageInfo.curPage + "");
    };
    /**
     * 添加行
     * @param addUIList
     * @param dataStatus
     * @param row
     */
    MyComponent.prototype.addUIRow = function (addUIList, dataStatus, row) {
        var i = 0;
        var tempList = [];
        for (; i < dataStatus.myData.length; i++) {
            tempList[i] = dataStatus.myData[i];
        }
        tempList[i] = row;
        dataStatus.myData = tempList;
        addUIList.push(row);
        console.log("添加行");
        console.log(addUIList);
    };
    /**
     * 删除行
     * @param deleteList
     * @param dataStatus
     * @param row
     * @param addList
     */
    MyComponent.prototype.deleteRow = function (deleteList, dataStatus, row, addList) {
        dataStatus.myData = dataStatus.myData.filter(function (item) {
            new Date(item.creationDate);
            return JSON.stringify(item) != row;
        });
        var hasAdd = false;
        addList.forEach(function (item) {
            if (JSON.stringify(item) == row) {
                console.log("是添加的行");
                hasAdd = true;
            }
        });
        addList = addList.filter(function (item) {
            return JSON.stringify(item) != row;
        });
        if (!hasAdd) {
            var i = 0;
            for (; i < deleteList.length; i++) {
                deleteList[i] = deleteList[i];
            }
            deleteList[i] = JSON.parse(row);
        }
        console.log("删除行");
        console.log(addList);
        return addList;
    };
    /**
     * 获取搜索的条件
     */
    MyComponent.prototype.getSearchJson = function () {
        return JSON.stringify((this.validateForm == undefined || this.validateForm == null) ? { 'null': null } : this.validateForm.value);
    };
    /**
     *
     * @param data 输入员工编号时候
     * @param event
     */
    MyComponent.prototype.onChangeEmp = function (event) {
        this.loadInputEmps(event);
    };
    /**
     * 加载输入的员工提示
     */
    MyComponent.prototype.loadInputEmps = function (inputValue) {
        var _this = this;
        this.evalService.getInputEmpList(inputValue).subscribe(function (res) {
            _this.options = res;
        });
    };
    return MyComponent;
}());



/***/ }),

/***/ "./src/app/content/content.component.css":
/*!***********************************************!*\
  !*** ./src/app/content/content.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbnRlbnQvY29udGVudC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/content/content.component.html":
/*!************************************************!*\
  !*** ./src/app/content/content.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  content works!\n</p>\n"

/***/ }),

/***/ "./src/app/content/content.component.ts":
/*!**********************************************!*\
  !*** ./src/app/content/content.component.ts ***!
  \**********************************************/
/*! exports provided: ContentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentComponent", function() { return ContentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ContentComponent = /** @class */ (function () {
    function ContentComponent() {
    }
    ContentComponent.prototype.ngOnInit = function () {
    };
    ContentComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-content',
            template: __webpack_require__(/*! ./content.component.html */ "./src/app/content/content.component.html"),
            styles: [__webpack_require__(/*! ./content.component.css */ "./src/app/content/content.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ContentComponent);
    return ContentComponent;
}());



/***/ }),

/***/ "./src/app/datasource/EvalDataSource.ts":
/*!**********************************************!*\
  !*** ./src/app/datasource/EvalDataSource.ts ***!
  \**********************************************/
/*! exports provided: EvalDataSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvalDataSource", function() { return EvalDataSource; });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/entity/DataStatus */ "./src/app/entity/DataStatus.ts");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/locales/zh */ "./node_modules/@angular/common/locales/zh.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");




var EvalDataSource = /** @class */ (function () {
    function EvalDataSource(evalService) {
        this.evalService = evalService;
        this.dataStatus = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__["DataStatus"]();
        this.dataStatus1 = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__["DataStatus"]();
        this.dataStatus2 = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__["DataStatus"]();
        Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["registerLocaleData"])(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_2___default.a);
    }
    /**
     * 加载人员范围
     * @param curPage
     */
    EvalDataSource.prototype.loadIncludeEmps = function (curPage) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.evalService.getIncludeEmps(curPage).subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus.pageInfo = result.data.pageInfo;
                _this.dataStatus.evalMgrSubject.next(result.data.listData);
                _this.dataStatus.myData = result.data.listData;
                console.log(result.data.listData);
                _this.dataStatus.length = result.data.listData.length;
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    /**
        * 加载所有线
        */
    EvalDataSource.prototype.loadHrDeptRegion = function (updateMap, curList) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.evalService.getHrDeptRegion().subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus.pageInfo = result.data.pageInfo;
                //判断是否有修改过的内容
                var dataArray = _this.checkUpdate(updateMap, curList, result.data.listData);
                _this.dataStatus.evalMgrSubject.next(dataArray);
                _this.dataStatus.myData = dataArray;
                console.log("loadHrDeptRegion-----");
                console.log(result.data.listData);
                _this.dataStatus.length = result.data.listData.length;
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    /**
     *
     * @param searchValue 加载所有部门
     */
    EvalDataSource.prototype.loadOgrList = function (searchValue) {
        var _this = this;
        this.evalService.getOrgList(searchValue).subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus2.myData = result.data.listData;
            });
        });
    };
    /**
        * 加载所有线与部门
        */
    EvalDataSource.prototype.loadHrDeptRegionDtl = function (updateMap, curList, searchValue) {
        var _this = this;
        this.dataStatus1.loadingEvalSubject.next(true);
        this.evalService.getHrDeptRegionDtl(searchValue).subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus1.pageInfo = result.data.pageInfo;
                //判断是否有修改过的内容
                var dataArray = _this.checkUpdate(updateMap, curList, result.data.listData);
                _this.dataStatus1.evalMgrSubject.next(dataArray);
                _this.dataStatus1.myData = dataArray;
                console.log("getHrDeptRegionDtl-----加载数据");
                console.log(result.data.listData);
                _this.dataStatus1.length = result.data.listData.length;
                _this.dataStatus1.loadingEvalSubject.next(false);
            });
        });
    };
    /**
     *
     * @param curPage 加载一次评语数据
     * @param updateMap
     * @param curList
     * @param searchValue
     * @param sortKey
     * @param sortValue
     */
    EvalDataSource.prototype.loadEval = function (curPage, updateMap, curList, searchValue, sortKey, sortValue) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.evalService.getEval(curPage, searchValue, sortKey, sortValue).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["catchError"])(this.evalService.handleError)).subscribe(function (res) {
            res.map(function (result) {
                console.log("result");
                console.log(result);
                console.log("result");
                _this.dataStatus.pageInfo = result.data.pageInfo;
                result.data.listData.forEach(function (item) {
                    if (item.firstSubmit != "Y") {
                        item.isUnSubmit = true;
                    }
                    else {
                        item.isUnSubmit = false;
                    }
                });
                //判断是否有修改过的内容
                var dataArray = _this.checkUpdate(updateMap, curList, result.data.listData);
                _this.dataStatus.myData = dataArray;
                _this.dataStatus.evalMgrSubject.next(dataArray);
                _this.dataStatus.length = result.data.listData.length;
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    /**
     * 加载评语分布率
     * @param year
     * @param updateMap
     * @param curList
     */
    EvalDataSource.prototype.loadEvalDistQuota = function (searchValue, updateMap, curList) {
        var _this = this;
        //开始加载
        this.dataStatus.loadingEvalSubject.next(true);
        this.evalService.getEvalDistQuotaByYear(searchValue).subscribe(function (res) {
            res.map(function (result) {
                //判断是否有修改过的内容
                var dataArray = _this.checkUpdate(updateMap, curList, result.data.listData);
                //存储数据
                _this.dataStatus.myData = dataArray;
                _this.dataStatus.pageDate = result.data;
                _this.dataStatus.evalMgrSubject.next(dataArray);
                //加载完毕
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    /**
     * 加载评价人员
     * @param searchValue
     * @param curPage
     */
    EvalDataSource.prototype.loadEvalEmployeeInfos = function (searchValue, curPage) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.evalService.getEvalEmployeeInfos(searchValue, curPage).subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus.myData = result.data.listData;
                _this.dataStatus.pageDate = result.data;
                _this.dataStatus.pageInfo = result.data.pageInfo;
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    EvalDataSource.prototype.loadOgrLeaderList = function (updateMap, curList) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.evalService.getOrgLeaderList().subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus.myData = _this.checkUpdate(updateMap, curList, result.data.listData);
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    EvalDataSource.prototype.checkUpdate = function (updateMap, curList, listData) {
        var dataArray = new Array();
        for (var i = 0; i < listData.length; i++) {
            var value = listData[i];
            var key = JSON.stringify(value);
            // console.log("key====》"+key)
            curList[i] = JSON.parse(JSON.stringify(value));
            if (curList.length > 0) {
                if (updateMap.get(key) != null) {
                    dataArray.push(updateMap.get(key));
                }
                else {
                    dataArray.push(value);
                }
            }
        }
        return dataArray;
    };
    return EvalDataSource;
}());



/***/ }),

/***/ "./src/app/datasource/SalaryDataSource.ts":
/*!************************************************!*\
  !*** ./src/app/datasource/SalaryDataSource.ts ***!
  \************************************************/
/*! exports provided: SalaryDataSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalaryDataSource", function() { return SalaryDataSource; });
/* harmony import */ var src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/entity/DataStatus */ "./src/app/entity/DataStatus.ts");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var SalaryDataSource = /** @class */ (function (_super) {
    __extends(SalaryDataSource, _super);
    function SalaryDataSource(salaryService) {
        var _this = _super.call(this, salaryService) || this;
        _this.salaryService = salaryService;
        _this.dataStatus = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_0__["DataStatus"]();
        _this.dataStatus1 = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_0__["DataStatus"]();
        _this.dataStatus2 = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_0__["DataStatus"]();
        return _this;
    }
    SalaryDataSource.prototype.loadSalaryHoliday = function (year, month, dataMap) {
        var _this = this;
        var yearMonth = year + "" + (month < 10 ? ("0" + month) : month);
        console.log('数据====》', dataMap);
        this.dataStatus.loadingEvalSubject.next(true);
        this.salaryService.getSlrHoliday(yearMonth).subscribe(function (res) {
            res.map(function (data) {
                console.log(data);
                _this.dataStatus.myData = data.data.listData;
                _this.dataStatus.myData.forEach(function (item) {
                    if (item.key != null) {
                        dataMap.get(item.key).dateType = item.dateType == "true";
                        dataMap.get(item.key).salaryDay = item.salaryDay == "true";
                        dataMap.get(item.key).key = item.key;
                        dataMap.get(item.key).dateDate = null;
                    }
                });
                console.log('数据=======》', _this.dataStatus.myData);
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    // public loadSpecialHumanItem(empCode: string , salaryItemCode: string): Observable<any> {
    //     return this.salaryService.getSpecialHumanConfigInfo(empCode,salaryItemCode);
    // }
    SalaryDataSource.prototype.loadSpecialHumanItem = function (updateMap, curList) {
        var _this = this;
        //开始加载
        this.dataStatus.loadingEvalSubject.next(true);
        this.salaryService.getSpecialHumanConfigInfo().subscribe(function (res) {
            res.map(function (result) {
                console.log('结果', result);
                //判断是否有修改过的内容
                var dataArray = _this.checkUpdate(updateMap, curList, result.data.listData);
                //存储数据
                _this.dataStatus.myData = dataArray;
                _this.dataStatus.pageDate = result.data;
                _this.dataStatus.anyData = [{ label: '不发该项工资', value: 'A' }, { label: '试用期不降挡', value: 'B' }];
                //加载完毕
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    return SalaryDataSource;
}(src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_1__["EvalDataSource"]));



/***/ }),

/***/ "./src/app/datasource/TargetDataSource.ts":
/*!************************************************!*\
  !*** ./src/app/datasource/TargetDataSource.ts ***!
  \************************************************/
/*! exports provided: TargetDataSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetDataSource", function() { return TargetDataSource; });
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
/* harmony import */ var src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/entity/DataStatus */ "./src/app/entity/DataStatus.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var TargetDataSource = /** @class */ (function (_super) {
    __extends(TargetDataSource, _super);
    function TargetDataSource(targetService) {
        var _this = _super.call(this, targetService) || this;
        _this.targetService = targetService;
        _this.dataStatus = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__["DataStatus"]();
        _this.dataStatus1 = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__["DataStatus"]();
        _this.dataStatus2 = new src_app_entity_DataStatus__WEBPACK_IMPORTED_MODULE_1__["DataStatus"]();
        return _this;
    }
    /**
     * 加载权限是否全部开放
     */
    TargetDataSource.prototype.loadAuthIsOpen = function () {
        var _this = this;
        this.targetService.getAuthIsOpen().subscribe(function (res) {
            res.map(function (val) {
                _this.dataStatus1.anyData = val.data;
            });
        });
    };
    /**
     * 加载所有的时间节点
     */
    TargetDataSource.prototype.loadAllDatePoint = function (updateMap, curList) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.targetService.getAllDatePoint().subscribe(function (res) {
            res.map(function (result) {
                _this.dataStatus.pageInfo = result.data.pageInfo;
                //判断是否有修改过的内容
                var dataArray = _this.checkUpdate(updateMap, curList, result.data.listData);
                _this.dataStatus.evalMgrSubject.next(dataArray);
                _this.dataStatus.myData = dataArray;
                console.log("loadAllDatePoint-----");
                console.log(result.data.listData);
                _this.dataStatus.length = result.data.listData.length;
                _this.dataStatus.loadingEvalSubject.next(false);
            });
        });
    };
    // 初始化EpmEvalInfo
    TargetDataSource.prototype.loadTodoList = function (year) {
        var _this = this;
        this.dataStatus.loadingEvalSubject.next(true);
        this.targetService.queryEvalInfo(year).subscribe(function (data) {
            // @ts-ignore
            _this.dataStatus.anyData = data;
            _this.dataStatus.loadingEvalSubject.next(false);
        });
    };
    // insert
    // @ts-ignore
    TargetDataSource.prototype.insertBpmVirtRecord = function (param) {
        return this.targetService.insertRecodeEval(param);
        // .subscribe(data => {
        //   // @ts-ignore
        //   this.dataStatus.length = data;
        //   alert(data);
        // });
    };
    // delete
    TargetDataSource.prototype.deleteVirtRecord = function (key) {
        return this.targetService.deleteVirtRecord(key);
    };
    // select 
    TargetDataSource.prototype.getEnddate = function (qN) {
        return this.targetService.getTempVerEndDate(qN);
    };
    return TargetDataSource;
}(src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_0__["EvalDataSource"]));



/***/ }),

/***/ "./src/app/entity/DataStatus.ts":
/*!**************************************!*\
  !*** ./src/app/entity/DataStatus.ts ***!
  \**************************************/
/*! exports provided: DataStatus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataStatus", function() { return DataStatus; });
/* harmony import */ var src_app_entity_PageInfo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/entity/PageInfo */ "./src/app/entity/PageInfo.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var src_app_entity_PageData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/entity/PageData */ "./src/app/entity/PageData.ts");



/**
 * 保存后台获取的数据以及状态
 */
var DataStatus = /** @class */ (function () {
    function DataStatus() {
        this.evalMgrSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]([]);
        this.myData = new Array();
        this.anyData = new Object();
        this.loadingEvalSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](false);
        this.pageInfo = new src_app_entity_PageInfo__WEBPACK_IMPORTED_MODULE_0__["PageInfo"]();
        this.pageDate = new src_app_entity_PageData__WEBPACK_IMPORTED_MODULE_2__["PageData"]();
        this.loading$ = this.loadingEvalSubject.asObservable();
        this.mapData = new Map();
    }
    return DataStatus;
}());



/***/ }),

/***/ "./src/app/entity/EvalVirtProc.ts":
/*!****************************************!*\
  !*** ./src/app/entity/EvalVirtProc.ts ***!
  \****************************************/
/*! exports provided: EvalVirtProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvalVirtProc", function() { return EvalVirtProc; });
var EvalVirtProc = /** @class */ (function () {
    function EvalVirtProc() {
    }
    return EvalVirtProc;
}());



/***/ }),

/***/ "./src/app/entity/HrDeptRegion.ts":
/*!****************************************!*\
  !*** ./src/app/entity/HrDeptRegion.ts ***!
  \****************************************/
/*! exports provided: HrDeptRegion */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HrDeptRegion", function() { return HrDeptRegion; });
var HrDeptRegion = /** @class */ (function () {
    function HrDeptRegion() {
    }
    return HrDeptRegion;
}());



/***/ }),

/***/ "./src/app/entity/HrDeptRegionDtl.ts":
/*!*******************************************!*\
  !*** ./src/app/entity/HrDeptRegionDtl.ts ***!
  \*******************************************/
/*! exports provided: HrDeptRegionDtl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HrDeptRegionDtl", function() { return HrDeptRegionDtl; });
var HrDeptRegionDtl = /** @class */ (function () {
    function HrDeptRegionDtl() {
    }
    return HrDeptRegionDtl;
}());



/***/ }),

/***/ "./src/app/entity/PageData.ts":
/*!************************************!*\
  !*** ./src/app/entity/PageData.ts ***!
  \************************************/
/*! exports provided: PageData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageData", function() { return PageData; });
var PageData = /** @class */ (function () {
    function PageData() {
    }
    return PageData;
}());



/***/ }),

/***/ "./src/app/entity/PageInfo.ts":
/*!************************************!*\
  !*** ./src/app/entity/PageInfo.ts ***!
  \************************************/
/*! exports provided: PageInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageInfo", function() { return PageInfo; });
var PageInfo = /** @class */ (function () {
    function PageInfo() {
    }
    return PageInfo;
}());



/***/ }),

/***/ "./src/app/entity/SalaryHoliday.ts":
/*!*****************************************!*\
  !*** ./src/app/entity/SalaryHoliday.ts ***!
  \*****************************************/
/*! exports provided: SalaryHoliday */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalaryHoliday", function() { return SalaryHoliday; });
var SalaryHoliday = /** @class */ (function () {
    function SalaryHoliday() {
    }
    return SalaryHoliday;
}());



/***/ }),

/***/ "./src/app/entity/SlrSpecialList.ts":
/*!******************************************!*\
  !*** ./src/app/entity/SlrSpecialList.ts ***!
  \******************************************/
/*! exports provided: SlrSpecialList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SlrSpecialList", function() { return SlrSpecialList; });
var SlrSpecialList = /** @class */ (function () {
    function SlrSpecialList() {
    }
    return SlrSpecialList;
}());



/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.css ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWwtZGF0YS1yZWFkeS1zdWIvcmVhZHktc3RlcC1maWZ0aC9yZWFkeS1zdGVwLWZpZnRoLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"steps-content step-content\"> \n    <div class=\"table-operations\">\n         <button nz-button   [disabled]='dataSource.dataStatus.loading$ | async' style=\"margin-bottom:5px;margin-left:88%\" (click)=\"saveOrgLeaderList()\" class=\"editable-add-btn\">保存</button>\n        </div>\n <nz-table \n #baseTable \n  nzBordered\n  nzSize=\"small\"\n  [nzLoading]=\"dataSource.dataStatus.loading$ | async\"\n  nzNoResult=\"无数据\"\n  nzShowQuickJumper=\"true\"\n   nzTitle =\"部门对应部门正职\"\n   nzFrontPagination=\"true\"\n   [(nzData)]=\"dataSource.dataStatus.myData\"\n   nzPageSize=\"13\"\n \n  >\n <thead>\n <tr> \n   <th>#</th>\n   <!-- <th> 线编号</th> -->\n   <th> 部门编号</th>\n   <th> 部门名称</th>\n   <th> 正职编号</th>\n   <th> 正职名称</th>\n  </tr>\n </thead>\n     <tr *ngFor=\"let data of baseTable.data;let i = index\">\n       <td>{{i+1}}</td>\n       <td>{{data.organizationCode}}</td>\n       <td>{{data.organizationName}}</td>\n       <td>\n         \n        <input nz-input  nzSize=\"default\"  placeholder=\"请输入员工编号或姓名\" \n         (change) = \"onChange(data)\" (ngModelChange)=\"onChangeEmp($event)\"  [(ngModel)]=\"data.leaderCode\" [nzAutocomplete]=\"auto\">\n      \n        <nz-autocomplete nzBackfill #auto>\n            <nz-auto-option *ngFor=\"let option of options\" [nzValue]=\"option.employeeCode\">\n            {{option.employeeCode}}\n            <span style=\" color: #999; \" >({{option.employeeName}})  </span>\n            </nz-auto-option>\n            </nz-autocomplete>\n\n      </td>\n       <!-- <td> <input nz-input  nzSize=\"default\"   (change)=\"onChange()\" [(ngModel)]=\"data.leaderName\" >  </td>   -->\n       <td>{{data.leaderName}}</td>\n     </tr>   \n </nz-table>\n</div>"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.ts ***!
  \************************************************************************************/
/*! exports provided: ReadyStepFifthComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadyStepFifthComponent", function() { return ReadyStepFifthComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var ReadyStepFifthComponent = /** @class */ (function (_super) {
    __extends(ReadyStepFifthComponent, _super);
    //注入路由信息,以及评价的服务
    function ReadyStepFifthComponent(routerInfo, evalService, fb, modalService, msg) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        return _this;
    }
    ReadyStepFifthComponent.prototype.loadData = function () {
        this.dataSource.loadOgrLeaderList(this.updateMap, this.curList);
    };
    ReadyStepFifthComponent.prototype.initSearchFields = function () {
        throw new Error("Method not implemented.");
    };
    ReadyStepFifthComponent.prototype.ngOnInit = function () {
        this.initTable(new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__["EvalDataSource"](this.evalService));
    };
    ReadyStepFifthComponent.prototype.onChange = function (data) {
        var _this = this;
        setTimeout(function () {
            // console.log( "data============>",data)
            // console.log( "options============>",this.options)
            _this.options.forEach(function (item) {
                if (item.employeeCode == data.leaderCode) {
                    console.log("当前item", item);
                    data.leaderName = item.employeeName;
                }
            });
        }, this.timeOutNum);
        this.updateList = this.changeStatu(this.curList, this.updateMap, this.updateList, this.dataSource.dataStatus);
        // this.options=this.options.filter(item=>item==null)
        console.log("更新集合", this.updateList);
    };
    ReadyStepFifthComponent.prototype.saveOrgLeaderList = function () {
        var _this = this;
        if (this.addUIList.length == 0 && this.updateList.length == 0 && this.deleteList.length == 0) {
            this.msg.info("未发生任何改动！");
        }
        else {
            console.log(JSON.stringify(this.addUIList));
            //获取新增的线
            //获取修改的线
            //获取删除的线
            this.evalService.saveOrgLeaderList(JSON.stringify(this.addUIList), JSON.stringify(this.deleteList), JSON.stringify(this.updateList)).subscribe(function (res) {
                //清空线的变化数据
                _this.success("保存成功！");
                //this.dataSource.loadOgrLeaderList(this.updateMap,this.curList);
                _this.initTable(new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__["EvalDataSource"](_this.evalService));
                _this.clearData();
            }, function (error) {
                _this.error("保存失败！");
            });
        }
    };
    ReadyStepFifthComponent.prototype.clearData = function () {
        //清空添加的数据
        this.addUIList = this.addUIList.filter(function (item) { return item == null; });
        //清空修改的数据
        this.updateList = this.updateList.filter(function (item) { return item == null; });
        this.updateMap.clear();
        //清空当前的数据
        this.curList = this.curList.filter(function (item) { return item == null; });
        //清空删除的数据
        this.deleteList = this.deleteList.filter(function (item) { return item == null; });
        console.log("清空执行===");
        console.log(this.addUIList);
    };
    ReadyStepFifthComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-ready-step-fifth',
            template: __webpack_require__(/*! ./ready-step-fifth.component.html */ "./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.html"),
            styles: [__webpack_require__(/*! ./ready-step-fifth.component.css */ "./src/app/eval-data-ready-sub/ready-step-fifth/ready-step-fifth.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"]])
    ], ReadyStepFifthComponent);
    return ReadyStepFifthComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.css ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWwtZGF0YS1yZWFkeS1zdWIvcmVhZHktc3RlcC1mb3VydGgvcmVhZHktc3RlcC1mb3VydGguY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.html":
/*!****************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ant-card\" style=\" width:100%\">\r\n  <div style=\"width:96%;margin-left:2%;padding-top:1%\">\r\n    <form nz-form [formGroup]=\"validateForm\" class=\"ant-advanced-search-form\" (ngSubmit)=\"searchEvalEmployeeInfos()\">\r\n      <div nz-row [nzGutter]=\"24\">\r\n        <div *ngFor=\"let control of controlArray\">\r\n        <div nz-col [nzSpan]=\"control.field=='dataDate'?24:8\"  [style.display]=\"control.show?'block':'none'\">\r\n            <nz-form-item *ngIf=\"control.field=='dataDate'\" nzFlex style=\"float:left;margin-left:1%\">\r\n                <nz-form-label nzRequired=\"true\" [nzFor]=\"control.field\"> {{control.val}}</nz-form-label>\r\n                <nz-form-control>\r\n                    <nz-date-picker  [(ngModel)]=\"evalService.dataDate\"   [formControlName]=\"control.field\" [attr.id]=\"control.field\"   nzFormat=\"yyyy-MM-dd\"></nz-date-picker>\r\n                    <nz-form-explain *ngIf=\"validateForm.get('dataDate').dirty && validateForm.get('dataDate').errors\">必须指定一个时间节点</nz-form-explain>\r\n                 </nz-form-control>\r\n              </nz-form-item>\r\n         \r\n          <nz-form-item *ngIf=\"control.field!='dataDate'\" nzFlex style=\"float:right;margin-right:30%\">\r\n            <nz-form-label [nzFor]=\"control.field\"> {{control.val}}</nz-form-label>\r\n            <nz-form-control>\r\n              <input nz-input placeholder=\"{{control.val}}\" [formControlName]=\"control.field\" [attr.id]=\"control.field\">\r\n            </nz-form-control>\r\n          </nz-form-item>\r\n        </div>\r\n      </div>\r\n      </div>\r\n      <div nz-row>\r\n          <nz-form-item>\r\n              <nz-form-control >\r\n        <div nz-col [nzSpan]=\"24\" style=\"text-align: right;\">\r\n          <button style=\"margin-left:15px\" nz-button [nzType]=\"'primary'\"  >搜索</button>\r\n\r\n          <button style=\"margin-left:15px\" nz-button (click)=\"resetForm()\">重置</button>\r\n          <!-- <a style=\"margin-left:15px;font-size:15px;color:blue\" (click)=\"toggleCollapse()\">\r\n            {{isCollapse?'展开':'收起'}}\r\n            <i nz-icon style=\"vertical-align:0em\" [type]=\"isCollapse?'down':'up'\"></i>\r\n          </a> -->\r\n        </div> \r\n        </nz-form-control>\r\n        </nz-form-item>\r\n      </div>\r\n    </form>\r\n\r\n  </div>\r\n\r\n\r\n  <div style=\" padding-bottom:5%\">\r\n      <!-- (validateForm.get('dataDate').dirty &&\r\n      validateForm.get('dataDate').errors)==true?\r\n      '必须指定一个时间节点才能开始同步数据！':'在这之后将会开始刷新数据，这将会耗时大约3分钟，是否继续？'  -->\r\n      <nz-popconfirm [nzTitle]=\"validateForm.value.dataDate==null?'必须指定一个时间节点才能开始同步数据！': '在这之后将会开始刷新 '+(validateForm.value.dataDate|date:'yyyy/MM/dd')+ ' 的数据，这将会耗时大约3分钟，是否继续？'\" (nzOnConfirm)=\"refreshData()\">\r\n      <button *ngIf=\"showRefresh\"   [nzType]=\"'primary'\"   nz-button  nz-popconfirm style=\"margin-bottom:5px\"  >刷新数据</button>\r\n      </nz-popconfirm>\r\n      <nz-progress  *ngIf=\"showProcess\" [(nzPercent)]=\"processRate\"></nz-progress>\r\n    <nz-table #ajaxTable nzBordered nzSize=\"small\" nzNoResult=\"无数据，请选择正确的时间节点刷新数据并点击搜索按钮\" nzShowQuickJumper=\"true\" nzTitle=\"年度评价人员信息表\" [nzFrontPagination]=\"false\"\r\n      [(nzData)]=\"dataSource.dataStatus.myData\" [nzLoading]=\"dataSource.dataStatus.loading$ | async\" [nzTotal]=\"dataSource.dataStatus.pageInfo.totalNum\"\r\n      [(nzPageIndex)]=\"dataSource.dataStatus.pageInfo.curPage\" [(nzPageSize)]=\"dataSource.dataStatus.pageInfo.pageSize\" \r\n      (nzPageIndexChange)=\"loadEvalByPage(dataSource.dataStatus.pageInfo.curPage+'')\">\r\n      <thead (nzSortChange)=\"sort($event)\" nzSingleSort>\r\n        <tr>\r\n          <th>#</th>\r\n          <th> 时间节点 </th>\r\n          <th> 员工编号 </th>\r\n          <th> 员工姓名 </th>\r\n          <th > 所属部门 </th>\r\n          <th> 岗位名称 </th>\r\n           \r\n        </tr>\r\n      </thead>\r\n      <tr *ngFor=\"let data of dataSource.dataStatus.myData;let i = index\">\r\n        <td>{{i+1}}</td>\r\n        <td>{{data.dataDate| date:'yyyy/MM/dd'}}</td>\r\n        <td> {{data.employeeCode}} </td>\r\n        <td>{{data.employeeName}}</td>\r\n        <td>{{data.orgNameSecond}}</td>\r\n        <td >{{data.positionName}}</td>\r\n      </tr>\r\n    </nz-table>\r\n\r\n  </div>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.ts ***!
  \**************************************************************************************/
/*! exports provided: ReadyStepFourthComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadyStepFourthComponent", function() { return ReadyStepFourthComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var ReadyStepFourthComponent = /** @class */ (function (_super) {
    __extends(ReadyStepFourthComponent, _super);
    //注入路由信息,以及评价的服务
    function ReadyStepFourthComponent(routerInfo, evalService, fb, modalService, msg) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        // 进度值
        _this.processRate = 0;
        //执行刷新的唯一标识
        _this.executorId = null;
        //是否展示刷新按钮
        _this.showRefresh = true;
        //是否展示进度条
        _this.showProcess = false;
        //定时程序是否在执行
        _this.isRefreshing = true;
        return _this;
    }
    /**
     * 加载数据
     */
    ReadyStepFourthComponent.prototype.loadData = function () {
        this.dataSource.loadEvalEmployeeInfos(this.getSearchJson(), this.curPage + "");
    };
    /**
     * 初始化搜索字段
     */
    ReadyStepFourthComponent.prototype.initSearchFields = function () {
        this.searchFields.set('dataDate', '时间节点');
        this.searchFields.set('employeeCode', '员工编号');
        this.searchFields.set('employeeName', '员工姓名');
        this.searchFields.set('orgNameSecond', '所属组织');
    };
    ReadyStepFourthComponent.prototype.ngOnInit = function () {
        //初始化进度
        this.getProcessRate();
        this.initSearchFields();
        //设置搜索条件展示数量
        _super.prototype.setSearchFieldsLimitForRow.call(this, 4);
        _super.prototype.initSearch.call(this);
        //设置时间必填
        this.validateForm.setControl("dataDate", new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required));
        //初始化表格
        _super.prototype.initTable.call(this, new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__["EvalDataSource"](this.evalService));
        this.searchEval();
    };
    /**
     * 搜索评价人员信息
     */
    ReadyStepFourthComponent.prototype.searchEvalEmployeeInfos = function () {
        var canSearch = true;
        for (var i in this.validateForm.controls) {
            this.validateForm.controls[i].markAsDirty();
            this.validateForm.controls[i].updateValueAndValidity();
        }
        console.log("状态====", this.validateForm.status);
        if (this.validateForm.status == "VALID") {
            this.searchEval();
        }
    };
    /**
     * 刷新数据
     */
    ReadyStepFourthComponent.prototype.refreshData = function () {
        if (this.validateForm.value.dataDate != null) {
            this.startRefresh();
        }
        else {
            console.error("没有输入时间");
        }
    };
    /**
     * 点击按钮确认就开始调用刷新程序
     * 返回结果如果不是null 那么就执行成功，将id保存，并且将状态改为开始
     * 保存之后开始定时获取进度
     */
    ReadyStepFourthComponent.prototype.startRefresh = function () {
        var _this = this;
        this.evalService.callRefreshEvalData(this.getSearchJson()).subscribe(function (res) {
            console.log("刷新程序的id==", res.data);
            if (res.data != null && res.data != "null") {
                _this.executorId = res.data;
                //获取进度，显示进度条
                if (_this.isRefreshing == false) {
                    _this.getProcessRate();
                }
            }
        });
    };
    /**
     * 定时获取进度
     */
    ReadyStepFourthComponent.prototype.getProcessRate = function () {
        var _this = this;
        var index = 1;
        this.interval = setInterval(function () {
            index++;
            console.log("当前的id==", _this.executorId);
            _this.evalService.getProcessRate(_this.executorId).subscribe(function (res) {
                console.log("获取进程结果==", res);
                if ("E" == res.rtnCode) {
                    _this.error(res.rtnMsg);
                    _this.showRefresh = true;
                    clearInterval(_this.interval);
                    _this.isRefreshing = false;
                }
                else if ("S" == res.rtnCode) {
                    if ("null" != res.data) {
                        _this.processRate = res.data;
                        _this.showRefresh = true;
                        _this.success(res.rtnMsg);
                        clearInterval(_this.interval);
                        _this.isRefreshing = false;
                    }
                }
                else {
                    if ("null" != res.data && res.data > 0) {
                        console.log(4);
                        if (_this.executorId == null || _this.executorId == '') {
                            _this.executorId = res.rtnMsg;
                        }
                        _this.processRate = res.data;
                        _this.showProcess = true;
                        _this.showRefresh = false;
                    }
                    if (index > 200 && (res.data == 'null') || res.data == null) {
                        clearInterval(_this.interval);
                    }
                }
            });
        }, 1000);
    };
    //销毁组件时清除定时器
    ReadyStepFourthComponent.prototype.ngOnDestroy = function () {
        if (this.interval) {
            clearInterval(this.interval);
        }
    };
    ReadyStepFourthComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-ready-step-fourth',
            template: __webpack_require__(/*! ./ready-step-fourth.component.html */ "./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.html"),
            styles: [__webpack_require__(/*! ./ready-step-fourth.component.css */ "./src/app/eval-data-ready-sub/ready-step-fourth/ready-step-fourth.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"]])
    ], ReadyStepFourthComponent);
    return ReadyStepFourthComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.css":
/*!*********************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.css ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWwtZGF0YS1yZWFkeS1zdWIvcmVhZHktc3RlcC1vbmUvcmVhZHktc3RlcC1vbmUuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"steps-content step-content\">\n        \n    <div class=\"table-operations\">\n        <!-- <nz-upload style=\"float:left\"\n        [nzAction]=\"evalService.postEmpRangeUrl\"\n        [nzFileList]=\"fileList\"\n        nzMultiple=\"false\"\n         nzLimit =\"1\"\n        nzName=\"excelFile\"\n        nzShowUploadList=\"false\"\n        [nzFilter]=\"filters\"\n        (nzChange)=\"handleChange($event)\">\n        <button nz-button style=\"margin-bottom:5px\">\n          <i nz-icon type=\"upload\"></i><span>上传Excel</span>\n        </button>\n       \n      </nz-upload> -->\n\n  <nz-upload  style=\"float:left\"\n        [nzAction]=\"evalService.postEmpRangeUrl\" [nzCustomRequest] =\"customReq\"\n      >\n        <button  [disabled]='dataSource.dataStatus.loading$ | async' nz-button style=\"margin-bottom:5px\">\n          <i nz-icon type=\"upload\"></i><span>上传Excel</span>\n        </button>\n       \n      </nz-upload>\n\n      \n      <button  [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"primary\" style=\"margin-bottom:5px;margin-left:5px \" (click)=\"downloadExcel()\" ><i nz-icon type=\"download\"></i>导出Excel</button>\n    </div>\n  \n    <nz-table \n    #baseTable \n     nzBordered\n     nzSize=\"small\"\n     [nzLoading]=\"dataSource.dataStatus.loading$ | async\"\n     nzNoResult=\"无数据\"\n     nzShowQuickJumper=\"true\"\n      nzTitle =\"评价人员范围\"\n      nzFrontPagination=\"true\"\n      [(nzData)]=\"dataSource.dataStatus.myData\"\n      nzPageSize=\"13\"\n    \n     >\n    <thead  >\n    <tr> \n      <th >#</th>\n      <th nzCustomFilter > 员工编号 <nz-dropdown nzTrigger=\"click\" [nzClickHide]=\"false\" #dropdown>\n          <i nz-icon type=\"search\" theme=\"outline\" class=\"ant-table-filter-icon\" [class.ant-table-filter-open]=\"dropdown.nzVisible\" nz-dropdown></i>\n          <!-- <i nz-icon type=\"smile-o\" class=\"ant-table-filter-icon\" [class.ant-table-filter-open]=\"dropdown.nzVisible\" nz-dropdown></i> -->\n          <div class=\"custom-filter-dropdown\">\n            <input type=\"text\"  style=\"width:60%\" nz-input placeholder=\"输入员工编号\" [(ngModel)]=\"searchValueCode\">\n            <button nz-button   [nzType]=\"'primary'\" (click)=\"searchUICode()\">查询</button>\n          </div>\n        </nz-dropdown> \n      </th>\n      <th nzCustomFilter > 员工姓名 <nz-dropdown nzTrigger=\"click\" [nzClickHide]=\"false\" #dropdown>\n          <i nz-icon type=\"search\" theme=\"outline\" class=\"ant-table-filter-icon\" [class.ant-table-filter-open]=\"dropdown.nzVisible\" nz-dropdown></i>\n          <!-- <i nz-icon type=\"smile-o\" class=\"ant-table-filter-icon\" [class.ant-table-filter-open]=\"dropdown.nzVisible\" nz-dropdown></i> -->\n          <div class=\"custom-filter-dropdown\">\n            <input type=\"text\"  style=\"width:60%\" nz-input placeholder=\"输入员工姓名\" [(ngModel)]=\"searchValueName\">\n            <button nz-button   [nzType]=\"'primary'\" (click)=\"searchUIName()\">查询</button>\n          </div>\n        </nz-dropdown> \n      </th>\n      <th > 是否参与评价 </th>\n      \n    </tr>\n    </thead>\n        <tr *ngFor=\"let data of baseTable.data;let i = index\">\n          <td>{{i+1}}</td>\n          <td>{{data.employeeCode}}</td>\n          <td>{{data.employeeName}}</td>\n          <td> {{data.isEnable=='Y'?'是':'否'}} </td>\n        </tr>   \n    </nz-table>\n</div>"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.ts ***!
  \********************************************************************************/
/*! exports provided: ReadyStepOneComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadyStepOneComponent", function() { return ReadyStepOneComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var ReadyStepOneComponent = /** @class */ (function (_super) {
    __extends(ReadyStepOneComponent, _super);
    //注入路由信息,以及评价的服务
    function ReadyStepOneComponent(routerInfo, evalService, fb, modalService, msg) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        //搜索条件
        _this.searchValueCode = '';
        _this.searchValueName = '';
        return _this;
    }
    ReadyStepOneComponent.prototype.ngOnInit = function () {
        this.curPage = 1;
        _super.prototype.initTable.call(this, new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_6__["EvalDataSource"](this.evalService));
    };
    /**
    * 加载数据
    */
    ReadyStepOneComponent.prototype.loadData = function () {
        //加载数据并且初始化当前的数据map,并且缓存当前数据集合
        this.dataSource.loadIncludeEmps(this.curPage + "");
    };
    /**
     * 初始化搜索
     */
    ReadyStepOneComponent.prototype.initSearchFields = function () {
        throw new Error("Method not implemented.");
    };
    /**
     * 搜索编号
     */
    ReadyStepOneComponent.prototype.searchUICode = function () {
        this.dataSource.dataStatus.myData = this.dataSource.dataStatus.evalMgrSubject.value;
        var data = new Array();
        var j = 0;
        for (var i = 0; i < this.dataSource.dataStatus.myData.length; i++) {
            if (this.dataSource.dataStatus.myData[i].employeeCode.indexOf(this.searchValueCode) !== -1) {
                data[j] = this.dataSource.dataStatus.myData[i];
                j++;
            }
        }
        this.dataSource.dataStatus.myData = data;
    };
    /**
  * 搜索姓名
  */
    ReadyStepOneComponent.prototype.searchUIName = function () {
        this.dataSource.dataStatus.myData = this.dataSource.dataStatus.evalMgrSubject.value;
        var data = new Array();
        var j = 0;
        for (var i = 0; i < this.dataSource.dataStatus.myData.length; i++) {
            if (this.dataSource.dataStatus.myData[i].employeeName.indexOf(this.searchValueName) !== -1) {
                data[j] = this.dataSource.dataStatus.myData[i];
                j++;
            }
        }
        this.dataSource.dataStatus.myData = data;
    };
    /*************************文件操作**********************************/
    /**
     * 导出为Excel
     */
    ReadyStepOneComponent.prototype.downloadExcel = function () {
        this.evalService.downLoadExcel();
    };
    /**
      * 上传成功
      */
    ReadyStepOneComponent.prototype.successUpload = function () {
        this.loadData();
        this.msg.info("上传成功！");
    };
    /**
   * 上传失败
   */
    ReadyStepOneComponent.prototype.errorUpload = function () {
        this.msg.info("上传失败！");
    };
    ReadyStepOneComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-ready-step-one',
            template: __webpack_require__(/*! ./ready-step-one.component.html */ "./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.html"),
            styles: [__webpack_require__(/*! ./ready-step-one.component.css */ "./src/app/eval-data-ready-sub/ready-step-one/ready-step-one.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"]])
    ], ReadyStepOneComponent);
    return ReadyStepOneComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.css ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWwtZGF0YS1yZWFkeS1zdWIvcmVhZHktc3RlcC1zZWNvbmQvcmVhZHktc3RlcC1zZWNvbmQuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.html":
/*!****************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"steps-content step-content\">\r\n    <div class=\"table-operations\">\r\n <button nz-button  [disabled]='dataSource.dataStatus.loading$ | async' style=\"margin-bottom:5px\" (click)=\"addRow()\" class=\"editable-add-btn\">添加</button>\r\n <button nz-button  [disabled]='dataSource.dataStatus.loading$ | async' style=\"margin-bottom:5px;margin-left:78%\" (click)=\"saveDeptRegion()\" class=\"editable-add-btn\">保存</button>\r\n </div>\r\n    <nz-table \r\n    #editRowTable \r\n     nzBordered\r\n     nzSize=\"small\"\r\n     [nzLoading]=\"dataSource.dataStatus.loading$ | async\"\r\n     nzNoResult=\"无数据\"\r\n     nzShowQuickJumper=\"true\"\r\n      nzTitle =\"线与线领导\"\r\n      nzFrontPagination=\"true\"\r\n      [(nzData)]=\"dataSource.dataStatus.myData\"\r\n      nzPageSize=\"13\"\r\n    \r\n     >\r\n    <thead>\r\n    <tr> \r\n      <th>#</th>\r\n      <th> 线编号</th>\r\n      <th> 线名称</th>\r\n      <th> 线领导编号</th>\r\n      <th> 线领导名称</th>\r\n      <th> 操作</th>\r\n    </tr>\r\n    </thead>\r\n        <tr *ngFor=\"let data of editRowTable.data;let i = index\">\r\n          <td>{{i+1}}</td>\r\n          <td> {{data.drCode}}     </td>\r\n          <td> {{data.drName }}  </td>\r\n          <td> <input nz-input  nzSize=\"default\" (ngModelChange)=\"onChangeEmp($event)\"  (change)=\"onChange(data)\" [(ngModel)]=\"data.drMgr\"  [nzAutocomplete]=\"auto\"> \r\n            <nz-autocomplete nzBackfill #auto>\r\n                <nz-auto-option *ngFor=\"let option of options\" [nzValue]=\"option.employeeCode\">\r\n                {{option.employeeCode}}\r\n                <span style=\" color: #999; \" >({{option.employeeName}})  </span>\r\n                </nz-auto-option>\r\n                </nz-autocomplete>\r\n               </td>\r\n          <td> <input nz-input  nzSize=\"default\"   (change)=\"onChange()\" [(ngModel)]=\"data.drMgrName\" >  </td>\r\n          <td>\r\n              <nz-popconfirm [nzTitle]=\"'确认删除?'\" (nzOnConfirm)=\"deleteUIRow(data)\">\r\n                <a nz-popconfirm>删除</a>\r\n              </nz-popconfirm>\r\n            </td>\r\n          \r\n        </tr>   \r\n    </nz-table>\r\n    <nz-divider></nz-divider>\r\n\r\n    <div class=\"steps-content step-content\">\r\n        <div class=\"table-operations\"   >\r\n    \r\n     <form  nz-form  [nzLayout]=\"'inline'\" [formGroup]=\"validateForm\"   >\r\n        <nz-form-item>\r\n        <nz-form-control>\r\n            <button   [disabled]='dataSource.dataStatus1.loading$ | async'   nz-button (click)=\"addRow1()\"  >添加</button>\r\n        </nz-form-control>\r\n        </nz-form-item>\r\n         <nz-form-item     *ngFor=\"let control of controlArray\"   >\r\n        <nz-form-control>\r\n            <nz-date-picker   nz-popover  nzTitle=\"提示\"  nzContent=\"该日期为年度评价时间节点，后续的时间节点都会引用该时间节点！\" [nzDisabled]=\"showReSet\"  [(ngModel)]=\"evalService.dataDate\"  [formControlName]=\"control.field\" [attr.id]=\"control.field\"  nzFormat=\"yyyy-MM-dd\"></nz-date-picker>\r\n        </nz-form-control>\r\n        </nz-form-item>\r\n     \r\n      <nz-form-item>\r\n      <nz-form-control>\r\n    <button   *ngIf=\"showSearch\" nz-button nzType=\"primary\"   [disabled]='dataSource.dataStatus1.loading$ | async'  (click)=\"searchDtl()\"  nzSearch>搜索</button>\r\n    </nz-form-control>\r\n    </nz-form-item>\r\n    <nz-form-item>\r\n        <nz-form-control>\r\n    <nz-popconfirm [nzTitle]=\"'重置之后将会清空之前未保存的修改，确认继续？'\" (nzOnConfirm)=\"reSetDate()\">\r\n    <button  *ngIf=\"showReSet\" nz-button nzType=\"primary\"  nz-popconfirm  nzSearch>重置</button>\r\n    </nz-popconfirm>\r\n    </nz-form-control>\r\n    </nz-form-item>\r\n      <nz-form-item style=\"margin-left:45% \" >\r\n        <nz-form-control>\r\n    <button nz-button (click)=\"saveDeptRegionDtl()\"  [disabled]='dataSource.dataStatus.loading$ | async' class=\"editable-add-btn\">保存</button>\r\n  </nz-form-control>\r\n</nz-form-item>\r\n    </form>\r\n  \r\n    </div>\r\n    <nz-table \r\n    #baseTable \r\n     nzBordered\r\n     nzSize=\"small\"\r\n     [nzLoading]=\"dataSource.dataStatus1.loading$ | async\"\r\n     nzNoResult=\"无数据,请选择正确的时间节点并点击搜索按钮\"\r\n     nzShowQuickJumper=\"true\"\r\n      nzTitle =\"线与部门的关系\"\r\n      nzFrontPagination=\"true\"\r\n      [(nzData)]=\"dataSource.dataStatus1.myData\"\r\n      nzPageSize=\"13\"\r\n    \r\n     >\r\n    <thead>\r\n    <tr> \r\n      <th>#</th>\r\n      <!-- <th> 线编号</th> -->\r\n      <th> 线名称</th>\r\n      <th> 开始时间</th>\r\n      <th> 结束时间</th>\r\n      <th> 部门</th>\r\n      <th> 操作</th>\r\n    </tr>\r\n    </thead>\r\n        <tr *ngFor=\"let data of baseTable.data;let i = index\">\r\n          <td>{{i+1}}</td>\r\n          <!-- <td> <input nz-input  nzSize=\"default\"   (change)=\"onChange1()\" [(ngModel)]=\"data.drCode\" >  </td> -->\r\n          <!-- <td> <input nz-input  nzSize=\"default\"   (change)=\"onChange1()\" [(ngModel)]=\"data.drName\" >  </td> -->\r\n         <td style=\"width:200px\"> <nz-select (ngModelChange)=\"onChange1()\" style=\"width:100%\"[(ngModel)]=\"data.drCode\"  nzAllowClear nzPlaceHolder=\"Choose\">\r\n              <nz-option *ngFor=\"let sel of dataSource.dataStatus.myData\" [nzValue]=\"sel.drCode\"  [nzLabel]=\"sel.drName\" [nzDisabled]=\"sel.isAdded==true?true:false\"></nz-option>\r\n            </nz-select>\r\n          </td>\r\n          <td style=\"width:200px\">  <nz-date-picker style=\"width:100%\"  [(ngModel)]=\"data.bdate\"  (ngModelChange)=\"onChange1()\"  nzFormat=\"yyyy-MM-dd\"></nz-date-picker></td> \r\n          <td style=\"width:200px\"> <nz-date-picker  style=\"width:100%\" [(ngModel)]=\"data.edate\"  (ngModelChange)=\"onChange1()\"  nzFormat=\"yyyy-MM-dd\"></nz-date-picker></td>\r\n          <!-- <td>{{ data.bdate | date:'yyyy/MM/dd'}}</td> -->\r\n          <!-- <td>{{ data.edate | date:'yyyy/MM/dd'}}</td> -->\r\n          <td>\r\n          <nz-select style=\"width:100%\"[(ngModel)]=\"data.orgCodeSecond\" (ngModelChange)=\"onChange1()\"  nzAllowClear nzPlaceHolder=\"请选择部门\">\r\n              <nz-option *ngFor=\"let sel of dataSource.dataStatus2.myData\" [nzValue]=\"sel.organizationCode\" [nzLabel]=\"sel.organizationName\"   ></nz-option>\r\n            </nz-select>\r\n            </td>\r\n          <!-- <td>{{data.orgCodeSecond}}</td> -->\r\n          <td>\r\n              <nz-popconfirm  *ngIf=\"data.isAdded\" [nzTitle]=\"'确认删除?'\" (nzOnConfirm)=\"deleteUIRow1(data)\">\r\n                <a nz-popconfirm>删除</a>\r\n              </nz-popconfirm>\r\n            </td>\r\n          \r\n          \r\n        </tr>   \r\n    </nz-table>\r\n  </div>"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.ts ***!
  \**************************************************************************************/
/*! exports provided: ReadyStepSecondComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadyStepSecondComponent", function() { return ReadyStepSecondComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_entity_HrDeptRegion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/entity/HrDeptRegion */ "./src/app/entity/HrDeptRegion.ts");
/* harmony import */ var src_app_entity_HrDeptRegionDtl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/entity/HrDeptRegionDtl */ "./src/app/entity/HrDeptRegionDtl.ts");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/locales/zh */ "./node_modules/@angular/common/locales/zh.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var ReadyStepSecondComponent = /** @class */ (function (_super) {
    __extends(ReadyStepSecondComponent, _super);
    //注入路由信息,以及评价的服务
    function ReadyStepSecondComponent(routerInfo, evalService, fb, modalService, msg, datePipe) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        _this.datePipe = datePipe;
        //缓存的当前列表的map
        _this.curList1 = new Array();
        //修改过的数据的map
        _this.updateMap1 = new Map();
        //修改过的数据的集合
        _this.updateList1 = [];
        //前端添加的集合
        _this.addUIList1 = [];
        //需要向后端删除的集合
        _this.deleteList1 = [];
        //是否显示重置
        _this.showReSet = false;
        //是否显示搜索
        _this.showSearch = true;
        return _this;
    }
    ReadyStepSecondComponent.prototype.loadData = function () {
        this.dataSource.loadHrDeptRegion(this.updateMap, this.curList);
        this.dataSource.loadHrDeptRegionDtl(this.updateMap1, this.curList1, this.getSearchJson());
    };
    ReadyStepSecondComponent.prototype.initSearchFields = function () {
        this.searchFields.set('dataDate', '日期指定');
    };
    ReadyStepSecondComponent.prototype.ngOnInit = function () {
        Object(_angular_common__WEBPACK_IMPORTED_MODULE_9__["registerLocaleData"])(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8___default.a);
        _super.prototype.initTable.call(this, new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_10__["EvalDataSource"](this.evalService));
        _super.prototype.initSearch.call(this);
        this.validateForm.value.dataDate = new Date();
    };
    /**
     * 改变行
     */
    ReadyStepSecondComponent.prototype.onChange = function (data) {
        var _this = this;
        //延迟执行
        setTimeout(function () {
            if (data != undefined)
                _this.options.forEach(function (item) {
                    if (item.employeeCode == data.drMgr) {
                        console.log("当前item", item);
                        data.drMgrName = item.employeeName;
                    }
                });
        }, this.timeOutNum);
        this.updateList = this.changeStatu(this.curList, this.updateMap, this.updateList, this.dataSource.dataStatus);
    };
    /**
   * 改变行
   */
    ReadyStepSecondComponent.prototype.onChange1 = function () {
        console.log(this.dataSource.dataStatus1.myData);
        console.log("改变");
        this.updateList1 = this.changeStatu(this.curList1, this.updateMap1, this.updateList1, this.dataSource.dataStatus1);
    };
    /**
     * 添加行
     */
    ReadyStepSecondComponent.prototype.addRow = function () {
        var region = new src_app_entity_HrDeptRegion__WEBPACK_IMPORTED_MODULE_6__["HrDeptRegion"]();
        region.drCode = this.getNewDrCode();
        region.drName = "";
        region.drMgr = "";
        region.drMgrName = "";
        region.isAdded = true;
        this.addUIRow(this.addUIList, this.dataSource.dataStatus, JSON.parse(JSON.stringify(region)));
        // console.log(this.dataSource.dataStatus.myData)
    };
    /**
     * 删除行
     */
    ReadyStepSecondComponent.prototype.deleteUIRow = function (row) {
        this.addUIList = this.deleteRow(this.deleteList, this.dataSource.dataStatus, JSON.stringify(row), this.addUIList);
    };
    /**
        * 添加行
        */
    ReadyStepSecondComponent.prototype.addRow1 = function () {
        var regionDtl = new src_app_entity_HrDeptRegionDtl__WEBPACK_IMPORTED_MODULE_7__["HrDeptRegionDtl"]();
        regionDtl.drCode = "";
        regionDtl.drName = "";
        regionDtl.isAdded = true;
        regionDtl.creationDate = new Date();
        this.addUIRow(this.addUIList1, this.dataSource.dataStatus1, JSON.parse(JSON.stringify(regionDtl)));
        // console.log(this.dataSource.dataStatus.myData)
    };
    /**
     * 删除行
     */
    ReadyStepSecondComponent.prototype.deleteUIRow1 = function (row) {
        this.addUIList1 = this.deleteRow(this.deleteList1, this.dataSource.dataStatus1, JSON.stringify(row), this.addUIList1);
    };
    /**
     * 获取新增的线编号
     */
    ReadyStepSecondComponent.prototype.getNewDrCode = function () {
        var tempCode = 0;
        if (this.addUIList.length == 0) {
            this.dataSource.dataStatus.myData.forEach(function (item) {
                var code = new String(item.drCode).substr(4, item.drCode.length);
                var codeNum = Number.parseInt(code);
                if (codeNum >= tempCode) {
                    tempCode = codeNum;
                }
            });
        }
        else {
            this.addUIList.forEach(function (item) {
                var code = new String(item.drCode).substr(4, item.drCode.length);
                var codeNum = Number.parseInt(code);
                if (codeNum >= tempCode) {
                    tempCode = codeNum;
                }
            });
        }
        return "DR00" + (tempCode + 1);
    };
    ReadyStepSecondComponent.prototype.searchDtl = function () {
        console.log(this.getSearchJson());
        //加载组织线关系
        this.dataSource.loadHrDeptRegionDtl(this.updateMap1, this.curList1, this.getSearchJson());
        //加载组织列表
        this.dataSource.loadOgrList(this.getSearchJson());
        this.showReSet = true;
        this.showSearch = false;
    };
    ReadyStepSecondComponent.prototype.reSetDate = function () {
        this.validateForm.reset();
        this.showReSet = false;
        this.showSearch = true;
        //清空部门与线关系的变化数据
        this.clearDeptRegionDtlData();
    };
    /**
     * 保存线
     */
    ReadyStepSecondComponent.prototype.saveDeptRegion = function () {
        var _this = this;
        if (this.addUIList.length == 0 && this.updateList.length == 0 && this.deleteList.length == 0) {
            this.msg.info("未发生任何改动！");
        }
        else {
            console.log(JSON.stringify(this.addUIList));
            //获取新增的线
            //获取修改的线
            //获取删除的线
            this.evalService.saveDeptRegion(JSON.stringify(this.addUIList), JSON.stringify(this.deleteList), JSON.stringify(this.updateList)).subscribe(function (res) {
                //清空线的变化数据
                _this.success("保存成功！");
                _this.clearDeptRegionData();
                _this.dataSource.loadHrDeptRegion(_this.updateMap, _this.curList);
            }, function (error) {
                _this.error("保存失败！");
            });
        }
    };
    /**
     * 保存线与部门关系
    */
    ReadyStepSecondComponent.prototype.saveDeptRegionDtl = function () {
        var _this = this;
        if (this.addUIList1.length == 0 && this.updateList1.length == 0 && this.deleteList1.length == 0) {
            this.msg.info("未发生任何改动！");
        }
        else {
            //获取新增的部门与线的关系
            //获取修改的部门与线的关系
            /*********** 先把日期格式化 因为日期toJSON 后的格式后台无法解析 ****************/
            //同时为部门名称赋值
            this.addUIList1.forEach(function (item) {
                item.bdate = _this.datePipe.transform(item.bdate, 'yyyy-MM-dd');
                item.edate = _this.datePipe.transform(item.edate, 'yyyy-MM-dd');
                item.creationDate = _this.datePipe.transform(item.creationDate, 'yyyy-MM-dd HH:mm:ss');
                _this.dataSource.dataStatus2.myData.forEach(function (item1) {
                    if (item1.organizationCode == item.orgCodeSecond) {
                        console.log("添加部门名称===>" + item1.organizationName);
                        item.orgNameSecond = item1.organizationName;
                    }
                });
            });
            //同时为部门名称赋值
            this.updateList1.forEach(function (item) {
                item.bdate = _this.datePipe.transform(item.bdate, 'yyyy-MM-dd');
                item.edate = _this.datePipe.transform(item.edate, 'yyyy-MM-dd');
                _this.dataSource.dataStatus2.myData.forEach(function (item1) {
                    if (item1.organizationCode == item.orgCodeSecond) {
                        item.orgNameSecond = item1.organizationName;
                    }
                });
            });
            /*********** 先把日期格式化 ****************/
            this.evalService.saveDeptRegionDtl(JSON.stringify(this.addUIList1), JSON.stringify(this.deleteList1), JSON.stringify(this.updateList1)).subscribe(function (res) {
                _this.success("保存成功！");
                _this.clearDeptRegionDtlData();
                _this.dataSource.loadOgrList(_this.getSearchJson());
                _this.dataSource.loadHrDeptRegionDtl(_this.updateMap1, _this.curList1, _this.getSearchJson());
            }, function (error) {
                _this.error("保存失败！");
            });
        }
        //获取删除的部门与线的关系（保存了的数据不能删除）
        //清空线的变化数据
    };
    ReadyStepSecondComponent.prototype.clearDeptRegionDtlData = function () {
        //清空添加的数据
        this.addUIList1 = this.addUIList1.filter(function (item) { return item == null; });
        //清空修改的数据
        this.updateList1 = this.updateList1.filter(function (item) { return item == null; });
        this.updateMap1.clear();
        //清空删除的数据
        this.deleteList1 = this.deleteList1.filter(function (item) { return item == null; });
        //清空当前的数据
        this.curList1 = this.curList1.filter(function (item) { return item == null; });
        console.log("清空执行===");
        console.log(this.addUIList1);
    };
    ReadyStepSecondComponent.prototype.clearDeptRegionData = function () {
        //清空添加的数据
        this.addUIList = this.addUIList.filter(function (item) { return item == null; });
        //清空修改的数据
        this.updateList = this.updateList.filter(function (item) { return item == null; });
        this.updateMap.clear();
        //清空当前的数据
        this.curList = this.curList.filter(function (item) { return item == null; });
        //清空删除的数据
        this.deleteList = this.deleteList.filter(function (item) { return item == null; });
        console.log("清空执行===");
        console.log(this.addUIList);
    };
    ReadyStepSecondComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-ready-step-second',
            template: __webpack_require__(/*! ./ready-step-second.component.html */ "./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.html"),
            styles: [__webpack_require__(/*! ./ready-step-second.component.css */ "./src/app/eval-data-ready-sub/ready-step-second/ready-step-second.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_3__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["DatePipe"]])
    ], ReadyStepSecondComponent);
    return ReadyStepSecondComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.css ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2YWwtZGF0YS1yZWFkeS1zdWIvcmVhZHktc3RlcC10aGlyZC9yZWFkeS1zdGVwLXRoaXJkLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"steps-content step-content\">\r\n\r\n  <div class=\"table-operations\">\r\n   \r\n      \r\n    <form nz-form [nzLayout]=\"'inline'\" [formGroup]=\"validateForm\">\r\n      <nz-form-item *ngIf=\"validateForm!=undefined &&validateForm!=null&&validateForm.value!=null&&validateForm.value.dataDate!=null \" >\r\n          <nz-form-control>\r\n            <nz-upload   [nzAction]=\"uploadDistQuotaUrl\"  [nzCustomRequest] =\"customReq\"    >\r\n              <button nz-button style=\"margin-bottom:5px;\">\r\n                <i nz-icon type=\"upload\"></i>\r\n                <span>上传Excel</span>\r\n              </button>\r\n            </nz-upload>\r\n          </nz-form-control>\r\n        </nz-form-item>\r\n      <nz-form-item *ngFor=\"let control of controlArray\">\r\n        <nz-form-control>\r\n          <nz-date-picker [nzDisabled]=\"showReSet\"   [(ngModel)]=\"evalService.dataDate\" [formControlName]=\"control.field\"\r\n           [attr.id]=\"control.field\" (ngModelChange)=\"dateChange($event)\" nzFormat=\"yyyy-MM-dd\"></nz-date-picker>\r\n        </nz-form-control>\r\n      </nz-form-item>\r\n      <nz-form-item>\r\n        <nz-form-control>\r\n          <button *ngIf=\"showSearch\" nz-button nzType=\"primary\" (click)=\"searchQuota()\" nzSearch>搜索</button>\r\n        </nz-form-control>\r\n      </nz-form-item>\r\n      <nz-form-item>\r\n        <nz-form-control>\r\n          <nz-popconfirm [nzTitle]=\"'重置之后将会清空之前未保存的修改，确认继续？'\" (nzOnConfirm)=\"reSetDate()\">\r\n            <button *ngIf=\"showReSet\" nz-button nzType=\"primary\" nz-popconfirm nzSearch>重置</button>\r\n          </nz-popconfirm>\r\n        </nz-form-control>\r\n      </nz-form-item>\r\n      <nz-form-item   *ngIf=\"validateForm!=undefined &&validateForm!=null&&validateForm.value!=null&&validateForm.value.dataDate!=null \"    >\r\n        <nz-form-control>\r\n          <button nz-button nzType=\"primary\" style=\"margin-bottom:5px;margin-left:5px \" (click)=\"downloadExcel()\">\r\n            <i nz-icon type=\"download\"></i>导出Excel</button>\r\n        </nz-form-control>\r\n      </nz-form-item>\r\n\r\n      <nz-form-item style=\"margin-left:40% \">\r\n        <nz-form-control>\r\n          <button nz-button (click)=\"saveEvalDistQuota()\" class=\"editable-add-btn\">保存</button>\r\n        </nz-form-control>\r\n       </nz-form-item>\r\n\r\n\r\n    </form>\r\n\r\n  </div>\r\n  <nz-table #baseTable nzBordered nzSize=\"small\" [nzLoading]=\"dataSource.dataStatus.loading$ | async\" nzNoResult=\"无数据,请选择正确的年份并点击搜索按钮\"\r\n    nzShowQuickJumper=\"true\" nzTitle=\"评语分布率调整\" nzFrontPagination=\"true\" [(nzData)]=\"dataSource.dataStatus.myData\" nzPageSize=\"13\">\r\n    <thead>\r\n      <tr>\r\n        <th>#</th>\r\n        <!-- <th> 线编号</th> -->\r\n        <th> 线名称</th>\r\n        <th> 部门</th>\r\n        <th> 等级</th>\r\n        <th> S指标</th>\r\n        <th> A指标</th>\r\n        <th> B指标</th>\r\n        <th> C指标</th>\r\n        <th> D指标</th>\r\n      </tr>\r\n    </thead>\r\n    <tr *ngFor=\"let data of baseTable.data;let i = index\">\r\n      <td>{{i+1}}</td>\r\n      <!-- <td> <input nz-input  nzSize=\"default\"   (change)=\"onChange1()\" [(ngModel)]=\"data.drCode\" >  </td> -->\r\n      <!-- <td> <input nz-input  nzSize=\"default\"   (change)=\"onChange1()\" [(ngModel)]=\"data.drName\" >  </td> -->\r\n      <td style=\"width:200px\">\r\n        <nz-select nzDisabled (ngModelChange)=\"onChange()\" style=\"width:100%\" [(ngModel)]=\"data.drCode\" nzAllowClear nzPlaceHolder=\"Choose\">\r\n          <nz-option *ngFor=\"let sel of dataSource.dataStatus.pageDate.selectLists.deptRegionList\" [nzValue]=\"sel.drCode\" [nzLabel]=\"sel.drName\"\r\n            [nzDisabled]=\"sel.isAdded==true?true:false\"></nz-option>\r\n        </nz-select>\r\n      </td>\r\n      <td>\r\n        <nz-select nzDisabled style=\"width:200px\" [(ngModel)]=\"data.deptNo\" (ngModelChange)=\"onChange()\" nzAllowClear nzPlaceHolder=\"请选择部门\">\r\n          <nz-option *ngFor=\"let sel of dataSource.dataStatus.pageDate.selectLists.orgList\" [nzValue]=\"sel.organizationCode\" [nzLabel]=\"sel.organizationName\"></nz-option>\r\n        </nz-select>\r\n      </td>\r\n      <td>\r\n        <nz-select nzDisabled style=\"width:100px\" [(ngModel)]=\"data.jobLevel\" (ngModelChange)=\"onChange()\" nzAllowClear nzPlaceHolder=\"请选择等级\">\r\n          <nz-option *ngFor=\"let sel of jobLevelArray\" [nzValue]=\"sel.jobLevel\" [nzLabel]=\"sel.jobLevelName\"></nz-option>\r\n        </nz-select>\r\n      </td>\r\n      <td style=\"width:200px\">\r\n        <nz-input-number [nzMin]=\"0\" [nzMax]=\"200\" [nzStep]=\"1\" nzSize=\"default\" (ngModelChange)=\"onChange()\"  [(ngModel)]=\"data.sResult\"></nz-input-number>\r\n      </td>\r\n      <td style=\"width:200px\">\r\n        <nz-input-number [nzMin]=\"0\" [nzMax]=\"200\" [nzStep]=\"1\" nzSize=\"default\" (ngModelChange)=\"onChange()\" [(ngModel)]=\"data.aResult\"></nz-input-number>\r\n      </td>\r\n      <td style=\"width:200px\">\r\n        <nz-input-number [nzMin]=\"0\" [nzMax]=\"200\" [nzStep]=\"1\"  nzSize=\"default\" (ngModelChange)=\"onChange()\" [(ngModel)]=\"data.bResult\"></nz-input-number>\r\n      </td>\r\n      <td style=\"width:200px\">\r\n        <nz-input-number [nzMin]=\"0\" [nzMax]=\"200\" [nzStep]=\"1\"  nzSize=\"default\" (ngModelChange)=\"onChange()\" [(ngModel)]=\"data.cResult\"></nz-input-number>\r\n      </td>\r\n      <td style=\"width:200px\">\r\n        <nz-input-number [nzMin]=\"0\" [nzMax]=\"200\" [nzStep]=\"1\"  nzSize=\"default\" (ngModelChange)=\"onChange()\" [(ngModel)]=\"data.dResult\"></nz-input-number>\r\n      </td>\r\n\r\n\r\n    </tr>\r\n  </nz-table>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.ts ***!
  \************************************************************************************/
/*! exports provided: ReadyStepThirdComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadyStepThirdComponent", function() { return ReadyStepThirdComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var ReadyStepThirdComponent = /** @class */ (function (_super) {
    __extends(ReadyStepThirdComponent, _super);
    //注入路由信息,以及评价的服务
    function ReadyStepThirdComponent(routerInfo, evalService, fb, modalService, msg, datePipe) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        _this.datePipe = datePipe;
        _this.jobLevelArray = [
            { jobLevel: '1', jobLevelName: '1' },
            { jobLevel: '2', jobLevelName: '2' },
            { jobLevel: '3', jobLevelName: '3' },
            { jobLevel: '4', jobLevelName: '4' },
            { jobLevel: '5', jobLevelName: '5' },
        ];
        //是否显示重置
        _this.showReSet = false;
        //是否显示搜索
        _this.showSearch = true;
        //上传评语分布率
        _this.uploadDistQuotaUrl = _this.evalService.uploadDistQuotaUrl;
        return _this;
    }
    ReadyStepThirdComponent.prototype.loadData = function () {
        this.dataSource.loadEvalDistQuota(this.getSearchJson(), this.updateMap, this.updateList);
    };
    ReadyStepThirdComponent.prototype.initSearchFields = function () {
        this.searchFields.set('dataDate', '日期指定');
    };
    ReadyStepThirdComponent.prototype.ngOnInit = function () {
        this.initTable(new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_7__["EvalDataSource"](this.evalService));
        _super.prototype.initSearch.call(this);
    };
    ReadyStepThirdComponent.prototype.searchQuota = function () {
        console.log(this.getSearchJson());
        //加载评语分布率
        this.dataSource.loadEvalDistQuota(this.getSearchJson(), this.updateMap, this.curList);
        //加载组织列表
        this.dataSource.loadOgrList(this.getSearchJson());
        this.showReSet = true;
        this.showSearch = false;
    };
    ReadyStepThirdComponent.prototype.reSetDate = function () {
        this.validateForm.reset();
        this.showReSet = false;
        this.showSearch = true;
        //清空评语分布率的变化数据
        this.clearEvalDistQuotaData();
    };
    ReadyStepThirdComponent.prototype.clearEvalDistQuotaData = function () {
        //清空修改的数据
        this.updateList = this.updateList.filter(function (item) { return item == null; });
        this.updateMap.clear();
        //清空当前的数据
        this.curList = this.curList.filter(function (item) { return item == null; });
        console.log("清空执行===");
    };
    /**
    * 导出为Excel
    */
    ReadyStepThirdComponent.prototype.downloadExcel = function () {
        console.log("导出执行===条件===" + this.getSearchJson());
        this.evalService.exportEvalDistQuota(this.getSearchJson());
    };
    /**
     * 当文件变化
     * @param info
     */
    ReadyStepThirdComponent.prototype.handleChange = function (info) {
        console.log(this.uploadDistQuotaUrl);
        var item = info.fileList[info.fileList.length - 1];
        if (item != null && item.status == 'done') {
            this.clearEvalDistQuotaData();
            this.dataSource.loadEvalDistQuota(this.getSearchJson(), this.updateMap, this.curList);
            this.msg.info("上传成功！");
        }
    };
    /**
     * 上传成功
     */
    ReadyStepThirdComponent.prototype.successUpload = function () {
        this.clearEvalDistQuotaData();
        this.dataSource.loadEvalDistQuota(this.getSearchJson(), this.updateMap, this.curList);
        this.msg.info("上传成功！");
    };
    /**
   * 上传失败
   */
    ReadyStepThirdComponent.prototype.errorUpload = function () {
        this.clearEvalDistQuotaData();
        // this.dataSource.loadEvalDistQuota(this.getSearchJson(),this.updateMap,this.curList);
        this.msg.info("上传失败！");
    };
    /**
     * 、日期变化
     * @param result
     */
    ReadyStepThirdComponent.prototype.dateChange = function (result) {
        console.log("日期变化", result);
        if (result != null)
            this.uploadDistQuotaUrl = this.evalService.uploadDistQuotaUrl + result.getTime();
    };
    /**
     * 改变行
     */
    ReadyStepThirdComponent.prototype.onChange = function () {
        this.updateList = this.changeStatu(this.curList, this.updateMap, this.updateList, this.dataSource.dataStatus);
    };
    ReadyStepThirdComponent.prototype.saveEvalDistQuota = function () {
        var _this = this;
        console.log(this.updateList);
        if (this.addUIList.length == 0 && this.updateList.length == 0 && this.deleteList.length == 0) {
            this.msg.info("未发生任何改动！");
        }
        else {
            console.log(JSON.stringify(this.updateList));
            //获取新增的评语分布率
            //获取修改的评语分布率
            //获取删除的评语分布率
            this.evalService.saveEvalDistQuota(JSON.stringify(this.addUIList), JSON.stringify(this.deleteList), JSON.stringify(this.updateList)).subscribe(function (res) {
                //清空线的变化数据
                _this.success("保存成功！");
                _this.clearEvalDistQuotaData();
                _this.dataSource.loadEvalDistQuota(_this.getSearchJson(), _this.updateMap, _this.curList);
            }, function (error) {
                _this.error("保存失败！");
            });
        }
    };
    ReadyStepThirdComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-ready-step-third',
            template: __webpack_require__(/*! ./ready-step-third.component.html */ "./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.html"),
            styles: [__webpack_require__(/*! ./ready-step-third.component.css */ "./src/app/eval-data-ready-sub/ready-step-third/ready-step-third.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]])
    ], ReadyStepThirdComponent);
    return ReadyStepThirdComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-data-ready/eval-data-ready.component.css":
/*!***************************************************************!*\
  !*** ./src/app/eval-data-ready/eval-data-ready.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "button{\r\n    margin-left:10px; \r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXZhbC1kYXRhLXJlYWR5L2V2YWwtZGF0YS1yZWFkeS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUJBQWlCO0NBQ3BCIiwiZmlsZSI6InNyYy9hcHAvZXZhbC1kYXRhLXJlYWR5L2V2YWwtZGF0YS1yZWFkeS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYnV0dG9ue1xyXG4gICAgbWFyZ2luLWxlZnQ6MTBweDsgXHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/eval-data-ready/eval-data-ready.component.html":
/*!****************************************************************!*\
  !*** ./src/app/eval-data-ready/eval-data-ready.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ant-card body-content\"  >\n  <div class=\"step-s\">\n    <nz-steps [nzCurrent]=\"current\">\n        <nz-step nzTitle=\"确认人员范围\"></nz-step>\n        <nz-step nzTitle=\"确认线与部门\"></nz-step>\n        <nz-step nzTitle=\"评语分布率调整\"></nz-step>\n        <nz-step nzTitle=\"时间节点数据初始化\"></nz-step>\n        <nz-step nzTitle=\"确认部门正职\"></nz-step>\n    \n      </nz-steps>\n  <router-outlet></router-outlet>\n     \n      <div class=\"steps-action\" style=\"padding-bottom:4%\">\n        <button nz-button nzType=\"default\" (click)=\"pre()\" *ngIf=\"current > 0\">\n          <span>上一步</span>\n        </button>\n        <button nz-button nzType=\"default\" (click)=\"next()\" *ngIf=\"current < 4\">\n          <span>下一步</span>\n        </button>\n        <button nz-button nzType=\"primary\" (click)=\"showUpdateDialog()\" *ngIf=\"current === 4\">\n          <span>完成</span>\n        </button>\n      </div>\n\n\n</div>\n\n<nz-modal [(nzVisible)]=\"isUpdataShow\" nzTitle=\"完成前的确认\" (nzOnCancel)=\"cancelUpdate()\" (nzOnOk)=\"handleOk()\" [nzOkLoading]=\"isOkLoading\">\n    <p>确认当前页面是否已经保存？如果确认将会以{{evalService.dataDate|date:'yyyy/MM/dd'}} 为时间节点准备年度评价数据。</p>\n  </nz-modal>\n</div>\n"

/***/ }),

/***/ "./src/app/eval-data-ready/eval-data-ready.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/eval-data-ready/eval-data-ready.component.ts ***!
  \**************************************************************/
/*! exports provided: EvalDataReadyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvalDataReadyComponent", function() { return EvalDataReadyComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var EvalDataReadyComponent = /** @class */ (function (_super) {
    __extends(EvalDataReadyComponent, _super);
    //注入路由信息,以及评价的服务
    function EvalDataReadyComponent(routerInfo, evalService, fb, modalService, msg, router) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        _this.router = router;
        _this.current = 0;
        _this.displayData = [];
        //搜索条件
        _this.searchValue = '';
        return _this;
    }
    EvalDataReadyComponent.prototype.loadData = function () {
        throw new Error("Method not implemented.");
    };
    EvalDataReadyComponent.prototype.initSearchFields = function () {
        throw new Error("Method not implemented.");
    };
    EvalDataReadyComponent.prototype.ngOnInit = function () {
    };
    /**
     * 上一步
     */
    EvalDataReadyComponent.prototype.pre = function () {
        this.current -= 1;
        this.changeContent(false);
    };
    /**
     * 下一步
     */
    EvalDataReadyComponent.prototype.next = function () {
        this.current += 1;
        this.changeContent(true);
    };
    /**
     * 完成
     */
    EvalDataReadyComponent.prototype.done = function () {
        console.log('done');
    };
    /**
     * 改变文字
     */
    EvalDataReadyComponent.prototype.changeContent = function (isNext) {
        var routerPromise;
        switch (this.current) {
            case 0: {
                routerPromise = this.router.navigate(["/eval/ready"]);
                this.catchRouter(routerPromise, isNext);
                break;
            }
            case 1: {
                routerPromise = this.router.navigate(["/eval/ready/stepsecond"]);
                this.catchRouter(routerPromise, isNext);
                break;
            }
            case 2: {
                routerPromise = this.router.navigate(["/eval/ready/stepthird"]);
                this.catchRouter(routerPromise, isNext);
                break;
            }
            case 3: {
                routerPromise = this.router.navigate(["/eval/ready/stepfourth"]);
                this.catchRouter(routerPromise, isNext);
                break;
            }
            case 4: {
                routerPromise = this.router.navigate(["/eval/ready/stepfifth"]);
                this.catchRouter(routerPromise, isNext);
                break;
            }
            case 5: {
                break;
            }
            default: {
            }
        }
    };
    EvalDataReadyComponent.prototype.catchRouter = function (routerPromise, isNext) {
        var _this = this;
        routerPromise.then(function (res) {
            console.log("捕获结果");
            console.log(res);
            if (!res) {
                if (isNext) {
                    _this.current -= 1;
                }
                else {
                    _this.current += 1;
                }
            }
        });
    };
    EvalDataReadyComponent.prototype.handleOk = function () {
        var _this = this;
        if (this.evalService.dataDate == null) {
            this.error("未指定时间节点，请前往上一步指定时间节点");
            this.isUpdataShow = false;
            this.isOkLoading = false;
        }
        else {
            this.isOkLoading = true;
            this.evalService.finishEvalReady().subscribe(function (res) {
                if (res.rtnCode == "S") {
                    _this.success("已经成功准备" + res.data + "年的年度评价数据！");
                    _this.isUpdataShow = false;
                    _this.isOkLoading = false;
                }
                else {
                    _this.error("失败，请指定时间节点！");
                    _this.isUpdataShow = false;
                    _this.isOkLoading = false;
                }
            }, function (error) {
                _this.error("失败,服务器异常");
                _this.isUpdataShow = false;
                _this.isOkLoading = false;
            });
        }
    };
    EvalDataReadyComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-eval-data-ready',
            template: __webpack_require__(/*! ./eval-data-ready.component.html */ "./src/app/eval-data-ready/eval-data-ready.component.html"),
            styles: [__webpack_require__(/*! ./eval-data-ready.component.css */ "./src/app/eval-data-ready/eval-data-ready.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_4__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], EvalDataReadyComponent);
    return EvalDataReadyComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-maintain/eval-maintain.component.css":
/*!***********************************************************!*\
  !*** ./src/app/eval-maintain/eval-maintain.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\r\n    width: 60%;\r\n  }\r\n  mat-paginator {\r\n    \r\n    width:100%;\r\n    text-align: center;\r\n    margin: 0 auto;\r\n  }\r\n  .mat-row{\r\n      height: 42px;\r\n  }\r\n  .mat-header-cell{\r\n      font-weight: bold;\r\n      font-size: 15px;\r\n      text-align: center;\r\n  }\r\n  .mat-cell{\r\n      text-align: center;\r\n  }\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXZhbC1tYWludGFpbi9ldmFsLW1haW50YWluLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0dBQ1o7RUFDRDs7SUFFRSxXQUFXO0lBQ1gsbUJBQW1CO0lBQ25CLGVBQWU7R0FDaEI7RUFDRDtNQUNJLGFBQWE7R0FDaEI7RUFDRDtNQUNJLGtCQUFrQjtNQUNsQixnQkFBZ0I7TUFDaEIsbUJBQW1CO0dBQ3RCO0VBQ0Q7TUFDSSxtQkFBbUI7R0FDdEIiLCJmaWxlIjoic3JjL2FwcC9ldmFsLW1haW50YWluL2V2YWwtbWFpbnRhaW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcclxuICAgIHdpZHRoOiA2MCU7XHJcbiAgfVxyXG4gIG1hdC1wYWdpbmF0b3Ige1xyXG4gICAgXHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgfVxyXG4gIC5tYXQtcm93e1xyXG4gICAgICBoZWlnaHQ6IDQycHg7XHJcbiAgfVxyXG4gIC5tYXQtaGVhZGVyLWNlbGx7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcbiAgLm1hdC1jZWxse1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/eval-maintain/eval-maintain.component.html":
/*!************************************************************!*\
  !*** ./src/app/eval-maintain/eval-maintain.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " \n<div class=\"ant-card\"  style=\"margin-left:15%;  width:70%\">\n<div  style=\"width:96%;margin-left:2%;padding-top:1%\"  >\n    <form nz-form [formGroup]=\"validateForm\" class=\"ant-advanced-search-form\">\n        <div nz-row [nzGutter]=\"24\"  >\n          <div nz-col [nzSpan]=\"8\" *ngFor=\"let control of controlArray\" [style.display]=\"control.show?'block':'none'\">\n          \n            \n            \n            <div *ngIf=\"control.field!='employeeLevel'\">\n            <nz-form-item nzFlex style=\"float:right;margin-right:30%\">\n              <nz-form-label [nzFor]=\"control.field\"> {{control.val}}</nz-form-label>\n              <nz-form-control>\n                <input nz-input placeholder=\"{{control.val}}\" [formControlName]=\"control.field\" [attr.id]=\"control.field\">\n              </nz-form-control>\n            </nz-form-item>\n          </div>\n          <!-- 这里是等级选择 -->\n          <div *ngIf=\"control.field=='employeeLevel'\">\n              <nz-form-item nzFlex style=\"float:right;margin-right:30%\">\n                <nz-form-label [nzFor]=\"control.field\"> {{control.val}}</nz-form-label>\n                <nz-form-control>\n                    <nz-select style=\"min-width: 174px ;\" [formControlName]=\"control.field\" [attr.id]=\"control.field\" [nzSize]=\"size\" nzMode=\"multiple\" \n                     nzPlaceHolder=\"请选择\">\n                        <nz-option *ngFor=\"let option of empLevelList\" [nzLabel]=\"option.label\" [nzValue]=\"option.value\" ></nz-option>\n                      </nz-select>\n                  <!-- <input nz-input placeholder=\"placeholder\" [formControlName]=\"control.field\" [attr.id]=\"control.field\"> -->\n                </nz-form-control>\n              </nz-form-item>\n            </div>\n\n\n\n          </div>\n        </div>\n        <div nz-row>\n          <div nz-col [nzSpan]=\"24\" style=\"text-align: right;\">\n            <button  [disabled]='dataSource.dataStatus.loading$ | async' style=\"margin-left:15px\" nz-button [nzType]=\"'primary'\" (click)=\"searchEval()\" >搜索</button>\n            \n            <button  [disabled]='dataSource.dataStatus.loading$ | async' style=\"margin-left:15px\" nz-button (click)=\"resetForm()\">重置</button>\n            <a style=\"margin-left:15px;font-size:15px;color:blue\" (click)=\"toggleCollapse()\">\n              {{isCollapse?'展开':'收起'}}\n              <i nz-icon style=\"vertical-align:0em\" [type]=\"isCollapse?'down':'up'\"></i>\n            </a>\n          </div>\n        </div>\n      </form>\n\n</div>\n\n\n<div style=\"width:96%;margin-left:2%;margin-top:1%;padding-bottom:5%\" >\n<nz-table \n#ajaxTable \n nzBordered\n nzSize=\"small\"\n nzNoResult=\"无数据\"\n nzShowQuickJumper=\"true\"\n  nzTitle =\"年度评价一次评价表\"\n[nzFrontPagination]=\"false\" \n[(nzData)]=\"dataSource.dataStatus.myData\"\n[nzLoading]=\"dataSource.dataStatus.loading$ | async\"\n[nzTotal]=\"dataSource.dataStatus.pageInfo.totalNum\"\n[(nzPageIndex)]=\"dataSource.dataStatus.pageInfo.curPage\"\n[(nzPageSize)]=\"dataSource.dataStatus.pageInfo.pageSize\"\n(nzPageIndexChange)=\"loadEvalByPage(dataSource.dataStatus.pageInfo.curPage+'')\"\n >\n<thead  (nzSortChange)=\"sort($event)\" nzSingleSort>\n<tr> \n  <th >#</th>\n  <th > 评价年份 </th>\n  <th > 员工编号 </th>\n  <th > 员工姓名 </th>\n  <th nzShowSort nzSortKey=\"employeeLevel\"> 员工等级 </th>\n  <th > 所属机构 </th>\n  <th  nzShowSort nzSortKey=\"levelFirst\"> 评价结果 </th>\n  <th  nzShowSort nzSortKey=\"mgrCode\"> 上级编号 </th>\n  <th   > 上级姓名 </th>\n  <th  nzShowSort nzSortKey=\"statu\" > 评价状态 </th>\n  <th style=\"height:40px;width:100px\" >操作 \n     <button *ngIf=\"updateList.length>0\" style=\"margin-left:5px\"   nzSize =\"small\" (click)=\"showUpdateDialog()\" nz-button nzType=\"primary\"> \n        <i  nz-icon type=\"check\"     ></i> </button>  </th>\n</tr>\n</thead>\n    <tr *ngFor=\"let data of dataSource.dataStatus.myData;let i = index\">\n      <td>{{i+1}}</td>\n      <td>{{data.evalYear}}</td>\n      <td> {{data.employeeCode}} </td>\n      <td>{{data.employeeName}}</td>\n      <td>{{data.employeeLevel}}</td>\n      <td style=\"max-width:300px\" >{{data.orgFullName}}</td>\n      <td>{{data.levelFirst}}</td>\n      <td>{{data.mgrCode}}</td>\n      <td>{{data.mgrName}}</td>\n      <td>{{data.statu}}</td>\n      <td>  <nz-switch   (click)=\"onChange()\"  [(ngModel)]=\"data.isUnSubmit\" nzCheckedChildren=\"未提交\" nzUnCheckedChildren=\"已提交\"></nz-switch>    </td>\n      \n    </tr>   \n</nz-table>\n \n</div> \n</div>\n<nz-modal [(nzVisible)]=\"isUpdataShow\" nzTitle=\"确认对话框\" (nzOnCancel)=\"cancelUpdate()\" (nzOnOk)=\"okUpdate()\" [nzOkLoading]=\"isOkLoading\">\n   \n  <p>修改数据如下：</p>\n  <div>\n    <nz-table #basicTable  [nzData]=\"updateList\" [nzBordered]=\"true\" nzSize=\"small\" nzPageSize=\"5\"\n    [nzTotal]=\"updateList.length\">\n        <thead>\n          <tr>\n            <td>员工姓名</td>\n            <td>修改后状态</td>\n          </tr>\n        </thead>\n        <tbody>\n        <tr *ngFor=\"let data of basicTable.data\">\n          <td>{{data.employeeName}}</td>\n          <td>{{data.isUnSubmit==false?'已提交':'未提交'}}</td>\n        </tr>\n        </tbody>\n    </nz-table>\n  </div>\n</nz-modal>"

/***/ }),

/***/ "./src/app/eval-maintain/eval-maintain.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/eval-maintain/eval-maintain.component.ts ***!
  \**********************************************************/
/*! exports provided: EvalMaintainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvalMaintainComponent", function() { return EvalMaintainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/datasource/EvalDataSource */ "./src/app/datasource/EvalDataSource.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var EvalMaintainComponent = /** @class */ (function (_super) {
    __extends(EvalMaintainComponent, _super);
    // 注入路由信息,以及评价的服务
    function EvalMaintainComponent(routerInfo, evalService, fb, modalService, msg) {
        var _this = _super.call(this, routerInfo, evalService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.evalService = evalService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        return _this;
    }
    EvalMaintainComponent.prototype.ngOnInit = function () {
        // 初始化搜索界面
        _super.prototype.initSearch.call(this);
        // 初始化职等下拉列表
        this.initEmpLevelList();
        // 初始化数据表
        _super.prototype.initTable.call(this, new src_app_datasource_EvalDataSource__WEBPACK_IMPORTED_MODULE_3__["EvalDataSource"](this.evalService));
    };
    /**
     * 加载数据方法
     */
    EvalMaintainComponent.prototype.loadData = function () {
        // 加载数据并且初始化当前的数据map,并且缓存当前数据集合
        this.dataSource.loadEval(this.curPage + '', this.updateMap, this.curList, JSON.stringify(this.validateForm.value), this.sortKey, this.sortValue);
    };
    /**
     * 初始化搜索
     */
    EvalMaintainComponent.prototype.initSearchFields = function () {
        this.searchFields.set('employeeCode', '员工编号');
        this.searchFields.set('employeeName', '员工姓名');
        this.searchFields.set('orgFullName', '所属组织');
        this.searchFields.set('employeeLevel', '员工等级');
        this.searchFields.set('levelFirst', '一次评价得分');
        // this.searchFields.set('mgrCode','上级编号');
        this.searchFields.set('mgrName', '上级姓名');
        // this.searchFields.set('statu','评价状态');
        // this.searchFields.set('firstSubmit','上级提交状态');
    };
    EvalMaintainComponent.prototype.onChange = function () {
        this.updateList = this.changeStatu(this.curList, this.updateMap, this.updateList, this.dataSource.dataStatus);
        console.log('之后集合');
        console.log(this.updateList);
    };
    EvalMaintainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-eval-maintain',
            template: __webpack_require__(/*! ./eval-maintain.component.html */ "./src/app/eval-maintain/eval-maintain.component.html"),
            styles: [__webpack_require__(/*! ./eval-maintain.component.css */ "./src/app/eval-maintain/eval-maintain.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"], src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_2__["EvalServiceService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"]])
    ], EvalMaintainComponent);
    return EvalMaintainComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_6__["MyComponent"]));



/***/ }),

/***/ "./src/app/eval-service/eval-service.service.ts":
/*!******************************************************!*\
  !*** ./src/app/eval-service/eval-service.service.ts ***!
  \******************************************************/
/*! exports provided: EvalServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvalServiceService", function() { return EvalServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/internal/operators/catchError */ "./node_modules/rxjs/internal/operators/catchError.js");
/* harmony import */ var rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var EvalServiceService = /** @class */ (function () {
    function EvalServiceService(http, downLoadHttp, message) {
        this.http = http;
        this.downLoadHttp = downLoadHttp;
        this.message = message;
        //本地开发模式
        // public  baseEvalUrl= "http://127.0.0.1:8700/eval";
        //测试环境
        this.baseEvalUrl = "http://172.16.134.98:8700/eval";
        // 查询年度评价数据
        this.searchUrl = this.baseEvalUrl + "/getEvalYearByCondition";
        // 修改年度评价数据
        this.updateUrl = this.baseEvalUrl + "/updateEvalYearMgr";
        // 查询人员范围
        this.searchIncludeEmpsUrl = this.baseEvalUrl + "/getEvalIncludeEmps";
        // 查询线
        this.searchHrDeptRegionUrl = this.baseEvalUrl + "/getHrDeptRegion";
        // 保存线修改
        this.saveHrDeptRegionUrl = this.baseEvalUrl + "/saveDeptRegionData";
        // 查询线与部门关系
        this.searchHrDeptRegionDtlUrl = this.baseEvalUrl + "/getHrDeptRegionDtl";
        // 保存线与部门关系
        this.saveHrDeptRegionDtlUrl = this.baseEvalUrl + "/saveDeptRegionDtlData";
        // 查询评语分布率
        this.searchEvalDistQuotaUrl = this.baseEvalUrl + "/getEvalDistQuota";
        //导出评语分布率
        this.exportEvalDistQuotaUrl = this.baseEvalUrl + "/exportEvalDistQuota";
        // 保存评语分布率
        this.saveEvalDistQuotaUrl = this.baseEvalUrl + "/saveEvalDistQuota";
        //获取所有部门
        this.searchOrgListUrl = this.baseEvalUrl + "/getOrgList";
        //导出人员范围
        this.downLoadEmpsUrl = this.baseEvalUrl + "/getExcel";
        //执行刷新数据分发
        this.refreshEvalDataUrl = this.baseEvalUrl + "/callRefreshEvalData";
        //获取进度
        this.getProcessRateUrl = this.baseEvalUrl + "/getProcessRate";
        //获取人员信息
        this.searchEvalEmployeeInfosUrl = this.baseEvalUrl + "/getEvalEmployeeInfos";
        //获取部门对应部门正职
        this.searchOrgLeaderUrl = this.baseEvalUrl + "/getOrgLeaderList";
        //保存部门对应部门正职
        this.saveOrgLeaderUrl = this.baseEvalUrl + "/saveOrgLeaderList";
        //获取输入的员工
        this.getInputEmpListUrl = this.baseEvalUrl + "/getInputEmpList";
        //完成年度评价数据准备
        this.finishEvalReadyUrl = this.baseEvalUrl + "/finishEvalReady";
        //上传评语分布率
        this.uploadDistQuotaUrl = this.baseEvalUrl + "/postExcelEvalDistQuota?year=";
        //上传人员范围
        this.postEmpRangeUrl = this.baseEvalUrl + "/postExcel";
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]();
    }
    /**
     * 查询评价记录
     * @param curPage
     * @param searchValue
     * @param sortKey
     * @param sortValue
     */
    EvalServiceService.prototype.getEval = function (curPage, searchValue, sortKey, sortValue) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('curPage', curPage).set('searchValue', searchValue).set('sortKey', sortKey).set('sortValue', sortValue);
        return this.http.get(this.searchUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 修改评价记录
     */
    EvalServiceService.prototype.updateEval = function (updateParams) {
        //请求头
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                'Content-Type': 'application/json',
                'Authorization': 'authToken'
            })
        };
        console.log("修改的参数是====>" + updateParams);
        return this.http.put(this.updateUrl, updateParams, httpOptions).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 下载文件
     * 使用Http组件获取返回的的数据，文件将会放在blob里面，然后构造 blob 模拟a标签 点击下载文件
     */
    EvalServiceService.prototype.downLoadExcel = function () {
        var _this = this;
        this.downLoadHttp.get(this.downLoadEmpsUrl, { responseType: _angular_http__WEBPACK_IMPORTED_MODULE_1__["ResponseContentType"].Blob }).subscribe(function (data) {
            _this.generateExcel(data, "人员范围.xls");
        });
    };
    /**
     * 导出评语分布率
     * @param searchValue
     */
    EvalServiceService.prototype.exportEvalDistQuota = function (searchValue) {
        var _this = this;
        var params = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["URLSearchParams"]();
        params.set("searchValue", searchValue);
        // const  headers= new Headers();
        // headers.set("content-type","application/text;charset=UTF-8")
        // headers.append("Authorization","authToken")
        var responseType = _angular_http__WEBPACK_IMPORTED_MODULE_1__["ResponseContentType"].Blob;
        this.downLoadHttp.get(this.exportEvalDistQuotaUrl, { params: params,
            // headers:headers, 
            responseType: responseType }).subscribe(function (data) {
            _this.generateExcel(data, "评语分布率.xls");
        });
    };
    /**
     * 下载生成Excel
     * @param data
     * @param title
     */
    EvalServiceService.prototype.generateExcel = function (data, title) {
        var link = document.createElement('a');
        var blob = new Blob([data.blob()], { type: 'application/vnd.ms-excel' });
        link.setAttribute('href', window.URL.createObjectURL(blob));
        link.setAttribute('download', title);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    /**
     * 获取人员 范围
     * @param curPage
     */
    EvalServiceService.prototype.getIncludeEmps = function (curPage) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("curPage", curPage);
        return this.http.get(this.searchIncludeEmpsUrl, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 获取所有的线
     */
    EvalServiceService.prototype.getHrDeptRegion = function () {
        return this.http.get(this.searchHrDeptRegionUrl).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
       * 获取所有的线与部门关系
       */
    EvalServiceService.prototype.getHrDeptRegionDtl = function (searchValue) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('searchValue', searchValue);
        return this.http.get(this.searchHrDeptRegionDtlUrl, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 获取所有的部门
     * @param searchValue
     */
    EvalServiceService.prototype.getOrgList = function (searchValue) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('searchValue', searchValue);
        return this.http.get(this.searchOrgListUrl, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 保存线的操作
     * @param addValue
     */
    EvalServiceService.prototype.saveDeptRegion = function (addValue, deleteValue, updateValue) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                'Content-Type': 'application/text',
                'Authorization': 'authToken'
            })
        };
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("addValue", addValue).set("deleteValue", deleteValue).set("updateValue", updateValue);
        return this.http.post(this.saveHrDeptRegionUrl, httpOptions, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
       * 保存线与部门关系的操作
       * @param addValue
       */
    EvalServiceService.prototype.saveDeptRegionDtl = function (addValue, deleteValue, updateValue) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                'Content-Type': 'application/text',
                'Authorization': 'authToken'
            })
        };
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("addValue", addValue).set("deleteValue", deleteValue).set("updateValue", updateValue);
        return this.http.post(this.saveHrDeptRegionDtlUrl, httpOptions, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 根据指定年份获取评语分布率
     * @param year
     */
    EvalServiceService.prototype.getEvalDistQuotaByYear = function (searchValue) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('searchValue', searchValue);
        return this.http.get(this.searchEvalDistQuotaUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 保存评语分布率
     * @param addValue
     * @param deleteValue
     * @param updateValue
     */
    EvalServiceService.prototype.saveEvalDistQuota = function (addValue, deleteValue, updateValue) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                'Content-Type': 'application/text',
                'Authorization': 'authToken'
            })
        };
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("addValue", addValue).set("deleteValue", deleteValue).set("updateValue", updateValue);
        return this.http.post(this.saveEvalDistQuotaUrl, httpOptions, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
      * 查询评价记录
      * @param curPage
      * @param searchValue
      * @param sortKey
      * @param sortValue
      */
    EvalServiceService.prototype.getEvalEmployeeInfos = function (searchValue, curPage) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('curPage', curPage).set('searchValue', searchValue);
        return this.http.get(this.searchEvalEmployeeInfosUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     *
     * @param datePoint 执行刷新程序并且返回id
     */
    EvalServiceService.prototype.callRefreshEvalData = function (datePoint) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("datePoint", datePoint);
        return this.http.get(this.refreshEvalDataUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     *
     * @param executorId 获取程序执行进度
     */
    EvalServiceService.prototype.getProcessRate = function (executorId) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("executorId", executorId);
        return this.http.get(this.getProcessRateUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     *  获取部门对应的部门正职
     */
    EvalServiceService.prototype.getOrgLeaderList = function () {
        return this.http.get(this.searchOrgLeaderUrl).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 获取员工
     * @param inputValue
     */
    EvalServiceService.prototype.getInputEmpList = function (inputValue) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("inputValue", inputValue);
        return this.http.get(this.getInputEmpListUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 保存部门对应的部门正职
     * @param addValue
     * @param deleteValue
     * @param updateValue
     */
    EvalServiceService.prototype.saveOrgLeaderList = function (addValue, deleteValue, updateValue) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                'Content-Type': 'application/text',
                'Authorization': 'authToken'
            })
        };
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("addValue", addValue).set("deleteValue", deleteValue).set("updateValue", updateValue);
        return this.http.post(this.saveOrgLeaderUrl, httpOptions, { params: params }).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 完成年度评价数据准备
     */
    EvalServiceService.prototype.finishEvalReady = function () {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("dataDate", this.dataDate.getTime() + "");
        return this.http.get(this.finishEvalReadyUrl, { params: params }).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    EvalServiceService.prototype.uploadExcel = function (item) {
        var formData = new FormData();
        formData.append('excelFile', item.file);
        var req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpRequest"]('POST', item.action, formData, {
            reportProgress: true,
            withCredentials: false,
        });
        return this.http.request(req);
    };
    /**
     * 异常处理
     * @param error
     */
    EvalServiceService.prototype.handleError = function (error) {
        //this.message.create('error',"服务器异常！");
        console.log("异常处理");
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('发生错误:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error("\u8FD4\u56DE\u72B6\u6001\u7801 " + error.status + ", " +
                ("\u8FD4\u56DE " + error.error));
            if (error.status.toString() == '500' || error.status.toString() == '0') {
                alert('服务器异常！');
            }
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])('请求失败');
    };
    ;
    EvalServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"]])
    ], EvalServiceService);
    return EvalServiceService;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <nav class=\"navbar navbar-expand-md bg-dark navbar-dark fixed-bottom\" >\r\n  <span style=\"color:white;margin-left:50%;\">@版权所有 2018-{{curYear}}</span> \r\n  </nav>\r\n  </div>\r\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
        this.curYear = new Date().getFullYear();
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/guard/RouterGuard.ts":
/*!**************************************!*\
  !*** ./src/app/guard/RouterGuard.ts ***!
  \**************************************/
/*! exports provided: RouterGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RouterGuard", function() { return RouterGuard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_interceptor_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/interceptor-service.service */ "./src/app/interceptor-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RouterGuard = /** @class */ (function () {
    function RouterGuard(interceptorService) {
        this.interceptorService = interceptorService;
    }
    RouterGuard.prototype.canActivate = function (route, state) {
        var _this = this;
        this.interceptorService.getAuth().subscribe(function (res) {
            if (!(res.code == "200" && res.data != null && res.data != "null")) {
                _this.interceptorService.gotoLogin();
                return false;
            }
        });
        return true;
    };
    RouterGuard.prototype.canDeactivate = function (component, currentRoute, currentState, nextState) {
        console.log("开始");
        if (this.checkEmpty(component.addUIList) && this.checkEmpty(component.addUIList1)
            && this.checkEmpty(component.updateList) && this.checkEmpty(component.updateList1)
            && this.checkEmpty(component.deleteList) && this.checkEmpty(component.deleteList1)) {
            console.log("通过了");
            return true;
        }
        else {
            component.error("您还没有保存，请先保存现有更改！");
            return false;
        }
    };
    RouterGuard.prototype.checkEmpty = function (list) {
        if (list == undefined || list == null || list.length == 0) {
            return true;
        }
    };
    RouterGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [src_app_interceptor_service_service__WEBPACK_IMPORTED_MODULE_1__["InterceptorServiceService"]])
    ], RouterGuard);
    return RouterGuard;
}());



/***/ }),

/***/ "./src/app/interceptor-service.service.ts":
/*!************************************************!*\
  !*** ./src/app/interceptor-service.service.ts ***!
  \************************************************/
/*! exports provided: InterceptorServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterceptorServiceService", function() { return InterceptorServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var InterceptorServiceService = /** @class */ (function () {
    function InterceptorServiceService(router, http) {
        this.router = router;
        this.http = http;
        this.authUrl = "http://172.16.90.68:7777/ssologin/service/ssologinuser";
        this.auth = false;
        this.logionUrl = "http://172.16.90.68:7777/ssologin/login.jsp?authn_try_count=0&contextType=external&username=string&contextValue=%2Foam&password=sercure_string&challenge_url=http%3A%2F%2F172.16.90.68%3A7777%2Fssologin%2Flogin.jsp&ssoCookie=disablehttponly&request_id=-7090512630440787505&locale=zh_CN&resource_url=http://172.16.90.68:7777/hrmaintain";
    }
    InterceptorServiceService.prototype.intercept = function (request, next) {
        console.log("拦截");
        return next.handle(request).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["mergeMap"])(function (event) {
            // if(request.url==this.authUrl){
            //  // console.log("url====》"+request.url)
            //  return of(event);
            // }else{
            //    if(!this.auth){
            //     this.gotoLogin();
            //   }
            // }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(event);
        }));
    };
    InterceptorServiceService.prototype.isAuth = function () {
        var _this = this;
        var flag = false;
        this.getAuth()
            .subscribe(function (res) {
            if (res.code == "200" && res.data != null && res.data != "null") {
                flag = true;
            }
            _this.auth = flag;
        });
        return flag;
    };
    InterceptorServiceService.prototype.gotoLogin = function () {
        window.location.href = this.logionUrl;
    };
    InterceptorServiceService.prototype.getAuth = function () {
        console.log("开始请求权限");
        var obs = this.http.get(this.authUrl);
        return obs;
    };
    InterceptorServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], InterceptorServiceService);
    return InterceptorServiceService;
}());



/***/ }),

/***/ "./src/app/nav/nav.component.css":
/*!***************************************!*\
  !*** ./src/app/nav/nav.component.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25hdi9uYXYuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/nav/nav.component.html":
/*!****************************************!*\
  !*** ./src/app/nav/nav.component.html ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand-md bg-dark navbar-dark\">\r\n  <div class=\"container\">\r\n  <div class = \"navbar-brand col-md-2\">\r\n<a  > <span style=\"font-size:20px;\" ><img src=\"http://172.16.90.67:7778/assets/public/images/logo.png\" width=\"90\" height=\"30\"> </span>  </a>\r\n</div>\r\n<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\"\r\n data-target=\"#collapsibleNavbar\">\r\n<span class = \"navbar-toggler-icon\"></span>\r\n</button>\r\n<div class=\"collapse navbar-collapse col-md-6\" id=\"collapsibleNavbar\">\r\n<ul class=\"navbar-nav\">\r\n<!-- <li class=\"nav-item\">\r\n<a class=\"nav-link\"  [routerLink]=\"['/home']\">首页</a>\r\n</li> -->\r\n<li style=\"display:none\" class=\"nav-item\">\r\n  <a class=\"nav-link\">CDP</a>\r\n</li>\r\n<li class=\"nav-item\">\r\n  \r\n  <nz-dropdown>\r\n     <a nz-dropdown class=\"nav-link\">目标登记</a>\r\n    <ul nz-menu nzSelectable>\r\n      <li nz-menu-item>\r\n        <a  style=\"text-decoration:none;\" [routerLink]=\"['/target/selfdate']\">自评时间节点修改</a>\r\n      </li>\r\n      <li nz-menu-item>\r\n        <a  style=\"text-decoration:none;\" [routerLink]=\"['/target/selfTodo']\">自评待办处理</a>\r\n      </li>\r\n    </ul>\r\n  </nz-dropdown>\r\n</li>\r\n<li class=\"nav-item\">\r\n    <nz-dropdown>\r\n        <a nz-dropdown class=\"nav-link\">\r\n          年度评价  \r\n        </a>\r\n        <ul nz-menu nzSelectable>\r\n          <li nz-menu-item>\r\n            <a  style=\"text-decoration:none;\" [routerLink]=\"['/eval/ready']\">年度评价数据准备</a>\r\n          </li>\r\n          <li nz-menu-item>\r\n              <a style=\"text-decoration:none;\"  [routerLink]=\"['/eval/first',1]\" >一次评语修改</a> \r\n          </li>\r\n        </ul>\r\n      </nz-dropdown>\r\n  <!-- <a class=\"nav-link\" [routerLink]=\"['/eval',1]\" >年度评价</a> -->\r\n</li>\r\n<li   class=\"nav-item\">\r\n \r\n  <nz-dropdown>\r\n    <a nz-dropdown class=\"nav-link\">薪酬自动化</a>\r\n   <ul nz-menu nzSelectable>\r\n     <li nz-menu-item>\r\n       <a  style=\"text-decoration:none;\" [routerLink]=\"['/salary/special']\">特殊人员名单配置</a>\r\n     </li>\r\n     <li nz-menu-item>\r\n       <a  style=\"text-decoration:none;\" [routerLink]=\"['/salary/holiday']\">节假日配置</a>\r\n     </li>\r\n   </ul>\r\n </nz-dropdown>\r\n</li>\r\n</ul>\r\n\r\n</div>\r\n<!-- <div class=\"input-group col-md-4\">\r\n  <input type=\"text\" class=\"form-control\" placeholder=\"输入关键词\" id=\"demo\" name=\"email\">\r\n  <div class=\"input-group-append\">\r\n    <button class=\"input-group-text btn\">搜索</button>\r\n  </div>\r\n</div> -->\r\n  </div>\r\n</nav>\r\n"

/***/ }),

/***/ "./src/app/nav/nav.component.ts":
/*!**************************************!*\
  !*** ./src/app/nav/nav.component.ts ***!
  \**************************************/
/*! exports provided: NavComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavComponent", function() { return NavComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var NavComponent = /** @class */ (function () {
    function NavComponent() {
    }
    NavComponent.prototype.ngOnInit = function () {
    };
    NavComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-nav',
            template: __webpack_require__(/*! ./nav.component.html */ "./src/app/nav/nav.component.html"),
            styles: [__webpack_require__(/*! ./nav.component.css */ "./src/app/nav/nav.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], NavComponent);
    return NavComponent;
}());



/***/ }),

/***/ "./src/app/no-auth-page/no-auth-page.component.css":
/*!*********************************************************!*\
  !*** ./src/app/no-auth-page/no-auth-page.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25vLWF1dGgtcGFnZS9uby1hdXRoLXBhZ2UuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/no-auth-page/no-auth-page.component.html":
/*!**********************************************************!*\
  !*** ./src/app/no-auth-page/no-auth-page.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>无权限访问</div>"

/***/ }),

/***/ "./src/app/no-auth-page/no-auth-page.component.ts":
/*!********************************************************!*\
  !*** ./src/app/no-auth-page/no-auth-page.component.ts ***!
  \********************************************************/
/*! exports provided: NoAuthPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoAuthPageComponent", function() { return NoAuthPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var NoAuthPageComponent = /** @class */ (function () {
    function NoAuthPageComponent() {
    }
    NoAuthPageComponent.prototype.ngOnInit = function () {
    };
    NoAuthPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-no-auth-page',
            template: __webpack_require__(/*! ./no-auth-page.component.html */ "./src/app/no-auth-page/no-auth-page.component.html"),
            styles: [__webpack_require__(/*! ./no-auth-page.component.css */ "./src/app/no-auth-page/no-auth-page.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], NoAuthPageComponent);
    return NoAuthPageComponent;
}());



/***/ }),

/***/ "./src/app/salary-service/salary.service.ts":
/*!**************************************************!*\
  !*** ./src/app/salary-service/salary.service.ts ***!
  \**************************************************/
/*! exports provided: SalaryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalaryService", function() { return SalaryService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/internal/operators/catchError */ "./node_modules/rxjs/internal/operators/catchError.js");
/* harmony import */ var rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_5__);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var SalaryService = /** @class */ (function (_super) {
    __extends(SalaryService, _super);
    function SalaryService(http, downLoadHttp, message) {
        var _this = _super.call(this, http, downLoadHttp, message) || this;
        _this.http = http;
        _this.downLoadHttp = downLoadHttp;
        _this.message = message;
        //请求头
        _this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/json',
            'Authorization': 'authToken'
        });
        //本地开发模式
        //public  baseEvalUrl= "http://127.0.0.1:8700/salary";
        //测试环境
        _this.baseEvalUrl = "http://172.16.134.98:8700/salary";
        //获取假期的地址
        _this.slrHolidayUrl = _this.baseEvalUrl + "/getSlrHoliday";
        // 特殊人员工资信息保存URL
        _this.saveSlrSpecialhandleURL = _this.baseEvalUrl + '/saveSpecialConfigItem';
        // 获取特殊配置人员信息和工资项信息URL
        _this.getSlrSpecialItemURL = _this.baseEvalUrl + '/querySalaryReadyInfo';
        _this.saveSlrHolidayUrl = _this.baseEvalUrl + "/saveSlrHoliday";
        return _this;
    }
    /**
     * 根据年月获取当月假期
     * @param yearMonth
     */
    SalaryService.prototype.getSlrHoliday = function (yearMonth) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set("yearMonth", yearMonth);
        var httpOptions = {
            headers: this.headers,
            params: params
        };
        return this.http.get(this.slrHolidayUrl, httpOptions).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_5__["catchError"])(this.handleError));
    };
    /**
     * 保存对节假日的修改
     * @param slrHoliday
     */
    SalaryService.prototype.saveSlrHoliday = function (slrHoliday) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set("slrHoliday", slrHoliday);
        var httpOptions = {
            headers: this.headers,
            params: params
        };
        return this.http.post(this.saveSlrHolidayUrl, null, httpOptions).pipe(
        //异常处理
        Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_5__["catchError"])(this.handleError));
    };
    /**
     * 获取特殊人员配置信息
     */
    SalaryService.prototype.getSpecialHumanConfigInfo = function () {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();
        var HttpOptions = {
            headers: this.headers,
            params: params
        };
        return this.http.post(this.getSlrSpecialItemURL, null, HttpOptions).pipe(Object(rxjs_internal_operators_catchError__WEBPACK_IMPORTED_MODULE_5__["catchError"])(this.handleError));
    };
    /**
     * 保存修改信息
     */
    SalaryService.prototype.saveSpecialUpdateInfo = function (updateList, deleteList, addList) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set("updateList", updateList).set("deleteList", deleteList).set("addList", addList);
        var HttpOptions = {
            headers: this.headers,
            params: params
        };
        return this.http.post(this.saveSlrSpecialhandleURL, null, HttpOptions).pipe();
    };
    SalaryService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_http__WEBPACK_IMPORTED_MODULE_3__["Http"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__["NzMessageService"]])
    ], SalaryService);
    return SalaryService;
}(src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_1__["EvalServiceService"]));



/***/ }),

/***/ "./src/app/salary/salary-holiday-config/salary-holiday-config.component.css":
/*!**********************************************************************************!*\
  !*** ./src/app/salary/salary-holiday-config/salary-holiday-config.component.css ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhbGFyeS9zYWxhcnktaG9saWRheS1jb25maWcvc2FsYXJ5LWhvbGlkYXktY29uZmlnLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/salary/salary-holiday-config/salary-holiday-config.component.html":
/*!***********************************************************************************!*\
  !*** ./src/app/salary/salary-holiday-config/salary-holiday-config.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<div class=\"ant-card\"  style=\"margin-left:15%;  width:70%\">\r\n    <div class=\"steps-content step-content\"> \r\n\r\n\r\n    <div style=\"margin-bottom:5px;\">\r\n    <nz-alert style=\"width: 300px;float:left;height:40px\"  nzMessage=\"当前日期: {{ selectedDate | date:'yyyy-MM-dd' }}\"></nz-alert>\r\n    <div style=\"float:right;height:40px\">\r\n      <label>年份选择：</label>\r\n  <nz-select style=\"width: 120px;height:40px\"  [(ngModel)]=\"selectedYear\" (ngModelChange)=\"yearChange($event)\"  >\r\n    <nz-option *ngFor=\"let option of years\" [nzValue]=\"option\" [nzLabel]=\"option\"></nz-option>\r\n  </nz-select>\r\n  <label>月份选择：</label>\r\n  <nz-select style=\"width: 120px;margin-left:10px;height:40px\"  [(ngModel)]=\"selectedMonth\" (ngModelChange)=\"monthChange($event)\"  >\r\n      <nz-option *ngFor=\"let option of months\" [nzValue]=\"option.value\" [nzLabel]=\"option.label\"></nz-option>\r\n    </nz-select>\r\n  </div>\r\n  <button nz-button nzType=\"primary\" (click)=\"seveHoliday()\" style=\"margin-right:50px;float:right\">保存</button>\r\n  </div>\r\n<nz-calendar nzMode='month' id=\"cal\"  [(ngModel)]=\"selectedDate\"   >\r\n    <ul *nzDateCell=\"let date\" class=\"events\" style=\"padding:0px\">\r\n        <ng-container *ngIf=\"selectedMonth==(date.getMonth())\" >\r\n            <ng-container  >\r\n              <table style=\"width:100%;height:100%\">\r\n                <tr >\r\n                  <td nzSize=\"small\" style=\"width:70%;height:30%\" ><nz-badge nzStatus=\"warning\" nzText=\"是否节假日\"></nz-badge></td>\r\n                  <td>  <nz-switch (ngModelChange)=\"holidayChange()\"  nzSize=\"small\" [nzDisabled]=\"selectedMonth!=(date.getMonth())\"  nzCheckedChildren=\"是\" nzUnCheckedChildren=\"否\" [(ngModel)]=\"dataMap.get(date.getFullYear()+'-'+date.getMonth()+'-'+date.getDate()).dateType\"></nz-switch></td>\r\n                </tr>\r\n                <tr>\r\n                    <td nzSize=\"small\"style=\"width:70%;height:30%\" ><nz-badge \r\n                       nzStatus=\"warning\" nzText=\"是否带薪\"></nz-badge></td>\r\n                    <td>  <nz-switch (ngModelChange)=\"salaryChange()\"   nzSize=\"small\" [nzDisabled]=\"selectedMonth!=(date.getMonth())\" nzCheckedChildren=\"是\" nzUnCheckedChildren=\"否\" [(ngModel)]=\"dataMap.get(date.getFullYear()+'-'+date.getMonth()+'-'+date.getDate()).salaryDay\"></nz-switch></td>\r\n                  </tr>\r\n              </table>\r\n            </ng-container>\r\n          </ng-container>\r\n    </ul>\r\n\r\n\r\n<!-- <ng-template #dateCellTpl >\r\n    <table style=\"width:130px;height:60px\">\r\n        <tr >\r\n          <td style=\"width:120px;height:30px\" ><nz-badge nzStatus=\"warning\" nzText=\"是否是节假日\"></nz-badge></td>\r\n          <td>  <nz-switch [nzDisabled]=\"activeMonth==\"   nzSize=\"small\" ngModel=\"true\"></nz-switch></td>\r\n        </tr>\r\n        <tr>\r\n            <td style=\"width:120px;height:30px\"><nz-badge nzStatus=\"warning\" nzText=\"是否带薪\"></nz-badge></td>\r\n            <td>  <nz-switch nzSize=\"small\" ngModel=\"true\"></nz-switch></td>\r\n          </tr>\r\n      </table>\r\n</ng-template> -->\r\n\r\n\r\n\r\n\r\n  </nz-calendar>\r\n  </div>\r\n  </div>\r\n  \r\n"

/***/ }),

/***/ "./src/app/salary/salary-holiday-config/salary-holiday-config.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/salary/salary-holiday-config/salary-holiday-config.component.ts ***!
  \*********************************************************************************/
/*! exports provided: SalaryHolidayConfigComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalaryHolidayConfigComponent", function() { return SalaryHolidayConfigComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_datasource_SalaryDataSource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/datasource/SalaryDataSource */ "./src/app/datasource/SalaryDataSource.ts");
/* harmony import */ var src_app_salary_service_salary_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/salary-service/salary.service */ "./src/app/salary-service/salary.service.ts");
/* harmony import */ var src_app_entity_SalaryHoliday__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/entity/SalaryHoliday */ "./src/app/entity/SalaryHoliday.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var SalaryHolidayConfigComponent = /** @class */ (function (_super) {
    __extends(SalaryHolidayConfigComponent, _super);
    //注入路由信息,以及评价的服务
    function SalaryHolidayConfigComponent(routerInfo, salaryService, fb, modalService, msg, datePipe) {
        var _this = _super.call(this, routerInfo, salaryService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.salaryService = salaryService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        _this.datePipe = datePipe;
        _this.dataMap = new Map();
        _this.years = [];
        _this.months = [{ value: 0, label: '1月' }, { value: 1, label: '2月' }, { value: 2, label: '3月' }, { value: 3, label: '4月' }, { value: 4, label: '5月' },
            { value: 5, label: '6月' }, { value: 6, label: '7月' }, { value: 7, label: '8月' }, { value: 8, label: '9月' }, { value: 9, label: '10月' },
            { value: 10, label: '11月' }, { value: 11, label: '12月' }];
        return _this;
    }
    //public dataMap :Map<string,any>;
    SalaryHolidayConfigComponent.prototype.loadData = function () {
        this.dataSource.loadSalaryHoliday(this.selectedYear, this.selectedMonth, this.dataMap);
    };
    SalaryHolidayConfigComponent.prototype.initSearchFields = function () {
        throw new Error("Method not implemented.");
    };
    SalaryHolidayConfigComponent.prototype.ngOnInit = function () {
        //获取当前年
        var curDate = new Date();
        this.years[0] = curDate.getFullYear() - 2;
        this.years[1] = curDate.getFullYear() - 1;
        this.years[2] = curDate.getFullYear();
        this.years[3] = curDate.getFullYear() + 1;
        this.years[4] = curDate.getFullYear() + 2;
        this.selectedYear = curDate.getFullYear();
        this.selectedMonth = curDate.getMonth();
        this.initDate();
        //移除选择日期的组件 使用自定义的日期选择器
        //  $('#cal').children().get(0).remove()
        this.removeHeader();
    };
    /**
     * 初始化选择的日期，并加载数据
     */
    SalaryHolidayConfigComponent.prototype.initDate = function () {
        console.log("当前月份==>" + this.selectedMonth);
        for (var i = 1; i <= 31; i++) {
            //  if(this.dataMap.get(this.selectedYear+"-"+this.selectedMonth+"-"+i)==null){
            this.dataMap.set(this.selectedYear + "-" + this.selectedMonth + "-" + i, new src_app_entity_SalaryHoliday__WEBPACK_IMPORTED_MODULE_8__["SalaryHoliday"]());
            // }
        }
        this.selectedDate = new Date(this.selectedYear, this.selectedMonth, 1);
        this.initTable(new src_app_datasource_SalaryDataSource__WEBPACK_IMPORTED_MODULE_6__["SalaryDataSource"](this.salaryService));
    };
    SalaryHolidayConfigComponent.prototype.monthChange = function (event) {
        console.log(event);
        this.selectedMonth = event;
        this.initDate();
    };
    SalaryHolidayConfigComponent.prototype.yearChange = function (event) {
        this.selectedYear = event;
        console.log(event);
        this.initDate();
    };
    SalaryHolidayConfigComponent.prototype.seveHoliday = function () {
        var _this = this;
        //获取当前时间
        var curDate = new Date(this.selectedYear, this.selectedMonth + 1, 0);
        //获取当月天数
        var maxDays = curDate.getDate();
        for (var i = 1; i <= maxDays; i++) {
            this.updateList[i - 1] = this.dataMap.get(this.selectedYear + '-' + this.selectedMonth + '-' + i);
        }
        console.log('保存----------', this.updateList);
        this.salaryService.saveSlrHoliday(JSON.stringify(this.updateList)).subscribe(function (res) {
            //清空修改的数据
            _this.updateList = _this.updateList.filter(function (item) { return item == null; });
            _this.initDate();
            _this.success("保存成功！");
        }, function (error) {
            _this.error("保存失败！");
        });
    };
    //移除选择日期的组件 使用自定义的日期选择器(IE使用)
    SalaryHolidayConfigComponent.prototype.removeHeader = function () {
        var interval = setInterval(function () {
            //console.log()
            var div = document.getElementById('cal');
            if (div.children.item(0).getAttribute('style') != 'display:none') {
                console.log(div.children.item(0).getAttribute('style'));
                div.children.item(0).setAttribute('style', 'display:none');
            }
            else {
                clearInterval(interval);
            }
        }, 50);
    };
    SalaryHolidayConfigComponent.prototype.holidayChange = function () {
        console.log('改变----------', this.dataMap);
    };
    SalaryHolidayConfigComponent.prototype.salaryChange = function () {
        console.log('改变----------', this.dataMap);
    };
    SalaryHolidayConfigComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-salary-holiday-config',
            template: __webpack_require__(/*! ./salary-holiday-config.component.html */ "./src/app/salary/salary-holiday-config/salary-holiday-config.component.html"),
            styles: [__webpack_require__(/*! ./salary-holiday-config.component.css */ "./src/app/salary/salary-holiday-config/salary-holiday-config.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_salary_service_salary_service__WEBPACK_IMPORTED_MODULE_7__["SalaryService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]])
    ], SalaryHolidayConfigComponent);
    return SalaryHolidayConfigComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/salary/salary-maintain/salary-maintain.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/salary/salary-maintain/salary-maintain.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhbGFyeS9zYWxhcnktbWFpbnRhaW4vc2FsYXJ5LW1haW50YWluLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/salary/salary-maintain/salary-maintain.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/salary/salary-maintain/salary-maintain.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\r\n  salary-maintain works!\r\n</p>\r\n"

/***/ }),

/***/ "./src/app/salary/salary-maintain/salary-maintain.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/salary/salary-maintain/salary-maintain.component.ts ***!
  \*********************************************************************/
/*! exports provided: SalaryMaintainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalaryMaintainComponent", function() { return SalaryMaintainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SalaryMaintainComponent = /** @class */ (function () {
    function SalaryMaintainComponent() {
    }
    SalaryMaintainComponent.prototype.ngOnInit = function () {
    };
    SalaryMaintainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-salary-maintain',
            template: __webpack_require__(/*! ./salary-maintain.component.html */ "./src/app/salary/salary-maintain/salary-maintain.component.html"),
            styles: [__webpack_require__(/*! ./salary-maintain.component.css */ "./src/app/salary/salary-maintain/salary-maintain.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], SalaryMaintainComponent);
    return SalaryMaintainComponent;
}());



/***/ }),

/***/ "./src/app/salary/salary-special-config/salary-special-config.component.css":
/*!**********************************************************************************!*\
  !*** ./src/app/salary/salary-special-config/salary-special-config.component.css ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhbGFyeS9zYWxhcnktc3BlY2lhbC1jb25maWcvc2FsYXJ5LXNwZWNpYWwtY29uZmlnLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/salary/salary-special-config/salary-special-config.component.html":
/*!***********************************************************************************!*\
  !*** ./src/app/salary/salary-special-config/salary-special-config.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ant-card\" style=\"margin-left:15%;  width:70%\">\r\n    <div class=\"steps-content step-content\">\r\n        <div style=\" width:100%;height:30px\">\r\n            <button nz-button [disabled]=\"this.dataSource.dataStatus.loading$ | async\"  style=\"margin-bottom:5px;float:left\" (click)=\"addRecord()\">增加</button>\r\n        <button nz-button [disabled]=\"this.dataSource.dataStatus.loading$ | async\"  style=\"margin-bottom:5px;float:right\"  (click)=\"saveUpdate()\">保存</button>\r\n        </div>\r\n        \r\n      <div>\r\n            <nz-table #baseTable\r\n            nzBordered\r\n            nzSize='small'\r\n            nzShowQuickJumper=\"true\"\r\n            [nzFrontPagination]=\"true\"\r\n            [nzData]=\"dataSource.dataStatus.myData\"\r\n            [nzLoading]=\"this.dataSource.dataStatus.loading$ | async\"\r\n            [nzPageSize]=\"13\"\r\n            nzTitle=\"特殊人员名单\"\r\n             >\r\n            <thead>\r\n              <tr>\r\n                <th>#</th>\r\n                <th style=\"width:200px\">职工号</th>\r\n                <th>职工姓名</th>\r\n                <th style=\"width:100px\">职工类型</th>\r\n                <th>工资项码</th>\r\n                <th>操作</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor=\"let data of baseTable.data,let i= index\">\r\n                <td>{{i+1}}</td>\r\n                <td><input nz-input  nzSize=\"default\" (ngModelChange)=\"onChangeEmp($event)\"  (change)=\"onChange(data)\" [(ngModel)]=\"data.employeeCode\"  [nzAutocomplete]=\"auto\"> \r\n                  <nz-autocomplete nzBackfill #auto>\r\n                      <nz-auto-option *ngFor=\"let option of options\" [nzValue]=\"option.employeeCode\">\r\n                      {{option.employeeCode}}\r\n                      <span style=\" color: #999; \" >({{option.employeeName}})  </span>\r\n                      </nz-auto-option>\r\n                      </nz-autocomplete></td>\r\n                <td>{{data.employeeName}}</td>\r\n                <td> <nz-select style=\"width: 100%\" (ngModelChange)=\"onChange(data)\"  [(ngModel)]=\"data.specialType\">\r\n                  <ng-container *ngFor=\"let option of dataSource.dataStatus.anyData\">\r\n                    <nz-option [nzLabel]=\"option.label\" [nzValue]=\"option.value\" ></nz-option>\r\n                  </ng-container>\r\n                  </nz-select></td>\r\n                <td>\r\n                  <nz-select style=\"width: 100%\" (ngModelChange)=\"onChange(data)\"  [(ngModel)]=\"data.salaryCode\">\r\n                  <ng-container *ngFor=\"let option of dataSource.dataStatus.pageDate.selectLists.salaryitem\">\r\n                    <nz-option [nzLabel]=\"option.salaryName\" [nzValue]=\"option.salaryCode\" ></nz-option>\r\n                  </ng-container>\r\n                </nz-select>\r\n              </td>\r\n              <td><nz-popconfirm [nzTitle]=\"'确认删除?'\" (nzOnConfirm)=\"deleteCurRecord(data)\">\r\n                  <a nz-popconfirm>删除</a>\r\n                </nz-popconfirm></td>\r\n              </tr>\r\n            </tbody>\r\n          </nz-table>\r\n        </div>\r\n    </div>"

/***/ }),

/***/ "./src/app/salary/salary-special-config/salary-special-config.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/salary/salary-special-config/salary-special-config.component.ts ***!
  \*********************************************************************************/
/*! exports provided: SalarySpecialConfigComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalarySpecialConfigComponent", function() { return SalarySpecialConfigComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var src_app_datasource_SalaryDataSource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/datasource/SalaryDataSource */ "./src/app/datasource/SalaryDataSource.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_salary_service_salary_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/salary-service/salary.service */ "./src/app/salary-service/salary.service.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_entity_SlrSpecialList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/entity/SlrSpecialList */ "./src/app/entity/SlrSpecialList.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var SalarySpecialConfigComponent = /** @class */ (function (_super) {
    __extends(SalarySpecialConfigComponent, _super);
    function SalarySpecialConfigComponent(routerInfo, salaryService, fb, modalService, msg) {
        var _this = _super.call(this, routerInfo, salaryService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.salaryService = salaryService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        return _this;
    }
    SalarySpecialConfigComponent.prototype.loadData = function () {
        this.dataSource.loadSpecialHumanItem(this.updateMap, this.curList);
    };
    SalarySpecialConfigComponent.prototype.initSearchFields = function () {
        throw new Error("Method not implemented.");
    };
    SalarySpecialConfigComponent.prototype.ngOnInit = function () {
        _super.prototype.initTable.call(this, new src_app_datasource_SalaryDataSource__WEBPACK_IMPORTED_MODULE_2__["SalaryDataSource"](this.salaryService));
    };
    /**
     * 动态提示
     * @param data
     */
    SalarySpecialConfigComponent.prototype.onChange = function (data) {
        var _this = this;
        //延迟执行
        setTimeout(function () {
            if (data != undefined)
                _this.options.forEach(function (item) {
                    if (item.employeeCode == data.employeeCode) {
                        //console.log( "当前item",item)
                        data.employeeName = item.employeeName;
                    }
                });
        }, this.timeOutNum);
        //console.log('curList',this.dataSource.dataStatus.myData);  
        this.updateList = this.changeStatu(this.curList, this.updateMap, this.updateList, this.dataSource.dataStatus);
        console.log('updateList', this.updateList);
    };
    /**
     * 增加一条记录
     */
    SalarySpecialConfigComponent.prototype.addRecord = function () {
        var slrSpecialList = new src_app_entity_SlrSpecialList__WEBPACK_IMPORTED_MODULE_7__["SlrSpecialList"]();
        //这个赋值顺序会影响到是否有重复数据的判断
        //因此顺序不能改变
        slrSpecialList.specialType = '';
        slrSpecialList.employeeCode = '';
        slrSpecialList.salaryCode = '';
        slrSpecialList.salaryName = '';
        slrSpecialList.employeeName = '';
        slrSpecialList.specialId = new Date().getTime();
        this.addUIRow(this.addUIList, this.dataSource.dataStatus, slrSpecialList);
    };
    /**
     * 删除配置信息表中的数据
     * @param data
     */
    SalarySpecialConfigComponent.prototype.deleteCurRecord = function (data) {
        this.addUIList = this.deleteRow(this.deleteList, this.dataSource.dataStatus, JSON.stringify(data), this.addUIList);
    };
    /***
     * 数据在add,update,delete后提交到数据库保存
     */
    SalarySpecialConfigComponent.prototype.saveUpdate = function () {
        var _this = this;
        console.log('数组 ===>', this.addUIList, this.updateList, this.deleteList);
        if (this.addUIList.length == 0 && this.updateList.length == 0 && this.deleteList.length == 0) {
            this.msg.info("未发生任何改动！");
        }
        else {
            var newArr = JSON.parse(JSON.stringify(this.dataSource.dataStatus.myData));
            var newSet_1 = new Set();
            newArr.forEach(function (item) {
                item.specialId = -1;
                item.salaryName = "null";
                newSet_1.add(JSON.stringify(item));
            });
            console.log('数组大小===>', newArr.length);
            console.log('Set大小===>', newSet_1.size);
            if (newArr.length != newSet_1.size) {
                this.warning();
            }
            else {
                this.salaryService.saveSpecialUpdateInfo(JSON.stringify(this.updateList), JSON.stringify(this.deleteList), JSON.stringify(this.addUIList)).subscribe(function (data) {
                    _this.clearData();
                    _this.loadData();
                    _this.success("数据保存成功");
                }, function (error) {
                    _this.error("数据保存失败");
                });
            }
        }
    };
    SalarySpecialConfigComponent.prototype.warning = function () {
        this.modalService.warning({
            nzTitle: '信息提示',
            nzContent: '存在重复的数据，请检查!'
        });
    };
    /**
     * 清空集合
     */
    SalarySpecialConfigComponent.prototype.clearData = function () {
        //清空添加的数据
        this.addUIList = this.addUIList.filter(function (item) { return item == null; });
        //清空修改的数据
        this.updateList = this.updateList.filter(function (item) { return item == null; });
        this.updateMap.clear();
        //清空当前的数据
        this.curList = this.curList.filter(function (item) { return item == null; });
        //清空删除的数据
        this.deleteList = this.deleteList.filter(function (item) { return item == null; });
        console.log("清空执行===");
        console.log(this.addUIList);
    };
    SalarySpecialConfigComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-salary-special-config',
            template: __webpack_require__(/*! ./salary-special-config.component.html */ "./src/app/salary/salary-special-config/salary-special-config.component.html"),
            styles: [__webpack_require__(/*! ./salary-special-config.component.css */ "./src/app/salary/salary-special-config/salary-special-config.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], src_app_salary_service_salary_service__WEBPACK_IMPORTED_MODULE_4__["SalaryService"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"]])
    ], SalarySpecialConfigComponent);
    return SalarySpecialConfigComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/target-service/target.service.ts":
/*!**************************************************!*\
  !*** ./src/app/target-service/target.service.ts ***!
  \**************************************************/
/*! exports provided: TargetService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetService", function() { return TargetService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/eval-service/eval-service.service */ "./src/app/eval-service/eval-service.service.ts");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var TargetService = /** @class */ (function (_super) {
    __extends(TargetService, _super);
    function TargetService(http, downLoadHttp, message) {
        var _this = _super.call(this, http, downLoadHttp, message) || this;
        _this.http = http;
        _this.downLoadHttp = downLoadHttp;
        _this.message = message;
        //请求头
        _this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
            'Content-Type': 'application/json',
            'Authorization': 'authToken'
        });
        //本地开发模式
        //public  baseEvalUrl= "http://127.0.0.1:8700/target";
        //测试环境
        _this.baseEvalUrl = "http://172.16.134.98:8700/target";
        //获取所有的时间节点
        _this.allDatePointUrl = _this.baseEvalUrl + "/getAllDatePoint";
        //获取权限是否打开
        _this.authIsOpenUrl = _this.baseEvalUrl + "/getAuthIsOpen";
        //修改权限是否打开
        _this.updateAllAuthUrl = _this.baseEvalUrl + "/updateAllAuth";
        //修改时间节点
        _this.updateDatePointUrl = _this.baseEvalUrl + "/updateDatePoint";
        // 获取evel信息
        _this.selectEvalInfoUrl = _this.baseEvalUrl + '/queryEmpEvalData';
        return _this;
    }
    /**
     * 获取所有的时间节点
     */
    TargetService.prototype.getAllDatePoint = function () {
        return this.http.get(this.allDatePointUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 获取权限是否打开
     */
    TargetService.prototype.getAuthIsOpen = function () {
        return this.http.get(this.authIsOpenUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    };
    /**
     * 修改权限是否全部打开
     * @param value
     */
    TargetService.prototype.updateAllAuth = function (value) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("value", value);
        var httpOptions = {
            headers: this.headers,
            params: params
        };
        return this.http.put(this.updateAllAuthUrl, null, httpOptions);
    };
    /**
     * 修改时间节点
     * @param addValue
     * @param deleteValue
     * @param updateValue
     */
    TargetService.prototype.updateDatePoint = function (addValue, deleteValue, updateValue) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set("addValue", addValue).set("deleteValue", deleteValue).set("updateValue", updateValue);
        var httpOptions = {
            headers: this.headers,
            params: params
        };
        return this.http.post(this.updateDatePointUrl, null, httpOptions);
    };
    // @ts-ignore
    TargetService.prototype.queryEvalInfo = function (year) {
        var param = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('year', year);
        var httpOptions = {
            headers: this.headers,
            params: param
        };
        // @ts-ignore 标记后面不做类型检查
        return this.http.get(this.selectEvalInfoUrl, httpOptions).pipe();
    };
    // @ts-ignore
    TargetService.prototype.insertRecodeEval = function (par) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('param', par);
        var HttpOptions = {
            headers: this.headers,
            params: params
        };
        // @ts-ignore
        return this.http.post(this.baseEvalUrl + '/insertEvalVirtRecord', null, HttpOptions).pipe();
    };
    // @ts-ignore
    TargetService.prototype.deleteVirtRecord = function (key) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('param', key);
        var HttpOptions = {
            headers: this.headers,
            params: params
        };
        // @ts-ignore
        return this.http.post(this.baseEvalUrl + '/deleteRocordProcess', null, HttpOptions).pipe();
    };
    TargetService.prototype.getTempVerEndDate = function (qN) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpParams"]().set('qN', qN);
        var HttpOptions = {
            headers: this.headers,
            params: params
        };
        // @ts-ignore
        return this.http.post(this.baseEvalUrl + '/getEndDate', null, HttpOptions).pipe();
    };
    TargetService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _angular_http__WEBPACK_IMPORTED_MODULE_2__["Http"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"]])
    ], TargetService);
    return TargetService;
}(src_app_eval_service_eval_service_service__WEBPACK_IMPORTED_MODULE_1__["EvalServiceService"]));



/***/ }),

/***/ "./src/app/target/target-maintain/target-maintain.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/target/target-maintain/target-maintain.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhcmdldC90YXJnZXQtbWFpbnRhaW4vdGFyZ2V0LW1haW50YWluLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/target/target-maintain/target-maintain.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/target/target-maintain/target-maintain.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  target-maintain works!\n</p>\n"

/***/ }),

/***/ "./src/app/target/target-maintain/target-maintain.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/target/target-maintain/target-maintain.component.ts ***!
  \*********************************************************************/
/*! exports provided: TargetMaintainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetMaintainComponent", function() { return TargetMaintainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var TargetMaintainComponent = /** @class */ (function () {
    function TargetMaintainComponent() {
    }
    TargetMaintainComponent.prototype.ngOnInit = function () {
    };
    TargetMaintainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-target-maintain',
            template: __webpack_require__(/*! ./target-maintain.component.html */ "./src/app/target/target-maintain/target-maintain.component.html"),
            styles: [__webpack_require__(/*! ./target-maintain.component.css */ "./src/app/target/target-maintain/target-maintain.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], TargetMaintainComponent);
    return TargetMaintainComponent;
}());



/***/ }),

/***/ "./src/app/target/target-self-date-maintain/target-self-date-maintain.component.css":
/*!******************************************************************************************!*\
  !*** ./src/app/target/target-self-date-maintain/target-self-date-maintain.component.css ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhcmdldC90YXJnZXQtc2VsZi1kYXRlLW1haW50YWluL3RhcmdldC1zZWxmLWRhdGUtbWFpbnRhaW4uY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/target/target-self-date-maintain/target-self-date-maintain.component.html":
/*!*******************************************************************************************!*\
  !*** ./src/app/target/target-self-date-maintain/target-self-date-maintain.component.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ant-card\"  style=\"margin-left:15%;  width:70%\">\r\n<div class=\"steps-content step-content\"> \r\n  <div class=\"table-operations\">\r\n      <label>自评权限是否已经全部放开：</label>\r\n      <nz-switch\r\n      nz-popconfirm nzTitle=\"是否确打开/关闭所有自评权限?\" (nzOnConfirm)=\"updateAllAuth()\"  \r\n      (click)=\"clickSwitch()\" [nzLoading]=\"loading\"  [nzControl]=\"true\" nzPlacement=\"right\"\r\n      nzCheckedChildren=\"是\" nzUnCheckedChildren=\"否\"\r\n       [(ngModel)]=\"dataSource.dataStatus1.anyData\"></nz-switch>\r\n       <button  [disabled]=\"dataSource.dataStatus1.anyData || (dataSource.dataStatus.loading$ | async)\" \r\n       nz-button style=\"margin-bottom:5px;margin-left:67%\" (click)=\"saveSelfDate()\" class=\"editable-add-btn\">保存</button>\r\n      </div>\r\n<nz-table \r\n #baseTable \r\n nzBordered\r\n nzSize=\"small\"\r\n [nzLoading]=\"dataSource.dataStatus.loading$ | async\"\r\n nzNoResult=\"无数据\"\r\n nzShowQuickJumper=\"true\"\r\n nzTitle =\"自评时间节点\"\r\n nzFrontPagination=\"true\"\r\n [(nzData)]=\"dataSource.dataStatus.myData\"\r\n nzPageSize=\"13\"\r\n\r\n>\r\n<thead>\r\n<tr> \r\n <th>#</th>\r\n <!-- <th> 线编号</th> -->\r\n <th> 类型</th>\r\n <th> 季度</th>\r\n <th> 开始时间</th>\r\n <th> 结束时间</th>\r\n</tr>\r\n</thead>\r\n   <tr *ngFor=\"let data of baseTable.data;let i = index\">\r\n     <td>{{i+1}}</td>\r\n     <td>{{data.typeName}}</td>\r\n     <td>{{data.quarterNumber}}</td>\r\n     <td style=\"width:300px\">  <nz-date-picker [nzDisabled]=\"dataSource.dataStatus1.anyData\" style=\"width:100%\"  [(ngModel)]=\"data.startDate\"  (ngModelChange)=\"onChange()\"  nzFormat=\"yyyy-MM-dd\"></nz-date-picker></td> \r\n     <td style=\"width:300px\"> <nz-date-picker [nzDisabled]=\"dataSource.dataStatus1.anyData\" style=\"width:100%\" [(ngModel)]=\"data.endDate\"  (ngModelChange)=\"onChange()\"  nzFormat=\"yyyy-MM-dd\"></nz-date-picker></td>\r\n          \r\n   </tr>   \r\n</nz-table>\r\n</div>\r\n</div>"

/***/ }),

/***/ "./src/app/target/target-self-date-maintain/target-self-date-maintain.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/target/target-self-date-maintain/target-self-date-maintain.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: TargetSelfDateMaintainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetSelfDateMaintainComponent", function() { return TargetSelfDateMaintainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_target_service_target_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/target-service/target.service */ "./src/app/target-service/target.service.ts");
/* harmony import */ var src_app_datasource_TargetDataSource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/datasource/TargetDataSource */ "./src/app/datasource/TargetDataSource.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var TargetSelfDateMaintainComponent = /** @class */ (function (_super) {
    __extends(TargetSelfDateMaintainComponent, _super);
    //注入路由信息,以及评价的服务
    function TargetSelfDateMaintainComponent(routerInfo, targetService, fb, modalService, msg, datePipe) {
        var _this = _super.call(this, routerInfo, targetService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.targetService = targetService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        _this.datePipe = datePipe;
        _this.loading = false;
        return _this;
    }
    TargetSelfDateMaintainComponent.prototype.loadData = function () {
        this.dataSource.loadAuthIsOpen();
        this.dataSource.loadAllDatePoint(this.updateMap, this.curList);
    };
    TargetSelfDateMaintainComponent.prototype.initSearchFields = function () {
        throw new Error("Method not implemented.");
    };
    TargetSelfDateMaintainComponent.prototype.ngOnInit = function () {
        this.initTable(new src_app_datasource_TargetDataSource__WEBPACK_IMPORTED_MODULE_6__["TargetDataSource"](this.targetService));
    };
    /**
    * 改变行
    */
    TargetSelfDateMaintainComponent.prototype.onChange = function () {
        console.log(this.dataSource.dataStatus1.myData);
        console.log("改变");
        this.updateList = this.changeStatu(this.curList, this.updateMap, this.updateList, this.dataSource.dataStatus);
    };
    TargetSelfDateMaintainComponent.prototype.saveSelfDate = function () {
        var _this = this;
        if (this.addUIList.length == 0 && this.updateList.length == 0 && this.deleteList.length == 0) {
            this.msg.info("未发生任何改动！");
        }
        else {
            console.log(JSON.stringify(this.addUIList));
            //获取新增的线
            //获取修改的线
            //获取删除的线
            //格式化日期
            this.updateList.forEach(function (item) {
                console.log('开始时间', item.startDate);
                item.startDate = _this.datePipe.transform(item.startDate, 'yyyy-MM-dd');
                item.creationDate = _this.datePipe.transform(item.creationDate, 'yyyy-MM-dd HH:mm:ss');
                item.lastUpdateDate = _this.datePipe.transform(item.lastUpdateDate, 'yyyy-MM-dd HH:mm:ss');
                console.log('开始时间', item.startDate);
                item.endDate = _this.datePipe.transform(item.endDate, 'yyyy-MM-dd');
            });
            this.targetService.updateDatePoint(JSON.stringify(this.addUIList), JSON.stringify(this.deleteList), JSON.stringify(this.updateList)).subscribe(function (res) {
                //清空线的变化数据
                _this.success("保存成功！");
                _this.clearselfDateData();
                _this.dataSource.loadAllDatePoint(_this.updateMap, _this.curList);
            }, function (error) {
                _this.error("保存失败！");
            });
        }
    };
    TargetSelfDateMaintainComponent.prototype.clearselfDateData = function () {
        //清空添加的数据
        this.addUIList = this.addUIList.filter(function (item) { return item == null; });
        //清空修改的数据
        this.updateList = this.updateList.filter(function (item) { return item == null; });
        this.updateMap.clear();
        //清空当前的数据
        this.curList = this.curList.filter(function (item) { return item == null; });
        //清空删除的数据
        this.deleteList = this.deleteList.filter(function (item) { return item == null; });
        console.log("清空执行===");
        console.log(this.addUIList);
    };
    TargetSelfDateMaintainComponent.prototype.updateAllAuth = function () {
        var _this = this;
        this.targetService.updateAllAuth((!this.dataSource.dataStatus1.anyData) + "").subscribe(function (res) {
            if (!_this.dataSource.dataStatus1.anyData) {
                _this.dataSource.dataStatus1.anyData = !_this.dataSource.dataStatus1.anyData;
                _this.success("权限打开成功！");
            }
            else if (_this.dataSource.dataStatus1.anyData) {
                _this.dataSource.dataStatus1.anyData = !_this.dataSource.dataStatus1.anyData;
                _this.success("权限关闭成功！");
            }
        }, function (response) {
            _this.error("操作失败！");
        });
        this.dataSource.loadAuthIsOpen();
        //this.dataSource.dataStatus1.anyData =  !this.dataSource.dataStatus1.anyData
        console.log(this.dataSource.dataStatus1.anyData);
    };
    TargetSelfDateMaintainComponent.prototype.clickSwitch = function () {
        var _this = this;
        if (!this.loading) {
            this.loading = true;
            setTimeout(function () {
                // this.switchValue = !this.switchValue;
                _this.loading = false;
            }, 10);
        }
    };
    TargetSelfDateMaintainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-target-self-date-maintain',
            template: __webpack_require__(/*! ./target-self-date-maintain.component.html */ "./src/app/target/target-self-date-maintain/target-self-date-maintain.component.html"),
            styles: [__webpack_require__(/*! ./target-self-date-maintain.component.css */ "./src/app/target/target-self-date-maintain/target-self-date-maintain.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_target_service_target_service__WEBPACK_IMPORTED_MODULE_5__["TargetService"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__["NzMessageService"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["DatePipe"]])
    ], TargetSelfDateMaintainComponent);
    return TargetSelfDateMaintainComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));



/***/ }),

/***/ "./src/app/target/target-self-todo/target-self-todo.component.css":
/*!************************************************************************!*\
  !*** ./src/app/target/target-self-todo/target-self-todo.component.css ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhcmdldC90YXJnZXQtc2VsZi10b2RvL3RhcmdldC1zZWxmLXRvZG8uY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/target/target-self-todo/target-self-todo.component.html":
/*!*************************************************************************!*\
  !*** ./src/app/target/target-self-todo/target-self-todo.component.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ant-card\" style=\"margin-left:15%;  width:70%\">\r\n  <div class=\"steps-content step-content\">\r\n\r\n    <table style=\"width:100%\">\r\n      <tr style=\"width:100%\">\r\n        <td style=\"width:33%\">\r\n          <nz-form-item nzFlex class=\"ant-advanced-search-form\">\r\n            <nz-form-label [nzFor]=\"dateSelector\">年份选择</nz-form-label>\r\n            <nz-form-control>\r\n              <nz-year-picker id=\"dateSelector\" [(ngModel)]=\"year\" (ngModelChange)=\"onChange($event)\" nzPlaceHolder=\"Select year\"></nz-year-picker>\r\n            </nz-form-control>\r\n          </nz-form-item>\r\n        </td>\r\n        <td style=\"width:33%\">\r\n          <nz-form-item nzFlex class=\"ant-advanced-search-form\">\r\n            <nz-form-label [nzFor]=\"'field1'\">{{searchFields.get('employeeName')}}</nz-form-label>\r\n            <nz-form-control>\r\n              <input nz-input placeholder=\"员工姓名\" (keydown)=\"search($event)\" name=\"employeeName\" [(ngModel)]=\"employeeName\" [attr.id]=\"'field'+'1'\">\r\n            </nz-form-control>\r\n          </nz-form-item>\r\n        </td>\r\n        <td style=\"width:33%\">\r\n          <nz-form-item nzFlex class=\"ant-advanced-search-form\">\r\n            <nz-form-label [nzFor]=\"'field2'\">{{searchFields.get('employeeCode')}}</nz-form-label>\r\n            <nz-form-control>\r\n              <input nz-input placeholder=\"员工编号\" (keydown)=\"search($event)\" name=\"employeeCode\" [(ngModel)]=\"employeeCode\" [attr.id]=\"'field'+'2'\">\r\n            </nz-form-control>\r\n          </nz-form-item>\r\n        </td>\r\n\r\n      </tr>\r\n      <tr>\r\n        <td></td>\r\n        <td></td>\r\n        <td>\r\n          <nz-form-item style=\"float:right;margin-right:42%\" nzFlex class=\"ant-advanced-search-form\">\r\n            <button nz-button [disabled]='dataSource.dataStatus.loading$ | async' [nzType]=\"'primary'\" (click)=\"selectByCondition()\">搜索</button>\r\n            <button nz-button  [disabled]='dataSource.dataStatus.loading$ | async'  [nzType]=\"'primary'\" style=\"margin-left:10px\" (click)=\"resetForm()\">清空</button>\r\n          </nz-form-item>\r\n        </td>\r\n      </tr>\r\n    </table>\r\n\r\n    <div>\r\n      <div>\r\n        <table style=\"width:60%\">\r\n          <tr style=\"width:60%;height:40px\">\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"primary\" (click)=\"selectTest('一,1')\">推送第一季度自评待办</button>\r\n            </td>\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async'  nz-button nzType=\"primary\" (click)=\"selectTest('二,2')\">推送第二季度自评待办</button>\r\n            </td>\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"primary\" (click)=\"selectTest('三,3')\">推送第三季度自评待办</button>\r\n            </td>\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async'  nz-button nzType=\"primary\" (click)=\"selectTest('四,4')\">推送第四季度自评待办</button>\r\n            </td>\r\n          </tr>\r\n\r\n          <tr style=\"width:60%\">\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"danger\" (click)=\"deleteTest('一,1')\">删除第一季度自评待办</button>\r\n            </td>\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"danger\" (click)=\"deleteTest('二,2')\">删除第二季度自评待办</button>\r\n            </td>\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"danger\" (click)=\"deleteTest('三,3')\">删除第三季度自评待办</button>\r\n            </td>\r\n            <td style=\"width:25%\">\r\n              <button style=\"width:180px\" [disabled]='dataSource.dataStatus.loading$ | async' nz-button nzType=\"danger\" (click)=\"deleteTest('四,4')\">删除第四季度自评待办</button>\r\n            </td>\r\n\r\n        </table>\r\n\r\n      </div>\r\n      <nz-table #rowSelectionTable [nzData]=\"dataSource.dataStatus.anyData\" [nzPageSize]=\"11\" nzBordered nzSize=\"small\" nzShowQuickJumper=\"true\"\r\n        [nzLoading]=\"dataSource.dataStatus.loading$ | async\" (nzPageIndexChange)=\"refreshStatus()\" (nzPageSizeChange)=\"refreshStatus()\">\r\n        <thead>\r\n          <tr>\r\n            <th nzShowCheckbox [nzIndeterminate]=\"indeterminate\"  [(nzChecked)]=\"allChecked\" \r\n              (nzCheckedChange)=\"checkAll($event)\"></th>\r\n            <th style=\"width:100px\">员工编号</th>\r\n            <th style=\"width:100px\">员工姓名</th>\r\n            <th style=\"width:100px\" >员工类型</th>\r\n            <th style=\"width:221px\">第一季度代办标题</th>\r\n            <th style=\"width:221px\">第二季度代办(年中)标题</th>\r\n            <th style=\"width:221px\">第三季度代办标题</th>\r\n            <th style=\"width:221px\">第四季度代办(年终)标题</th>\r\n          </tr>\r\n        </thead>\r\n        <tbody>\r\n          <tr *ngFor=\"let data of rowSelectionTable.data\">\r\n            <td nzShowCheckbox [(nzChecked)]=\"data.checked\" (nzCheckedChange)=\"refreshStatus()\"></td>\r\n            <td style=\"width:100px\">{{data.employeeCode}}</td>\r\n            <td style=\"width:100px\">{{data.employeeName}}</td>\r\n            <td style=\"width:100px\">模板{{data.tarTemplate}}</td>\r\n            <td style=\"width:221px\">{{data.q1t==null?'无需自评待办':data.q1t}}</td>\r\n            <td style=\"width:221px\">{{data.q2t}}</td>\r\n            <td style=\"width:221px\">{{data.q3t==null?'无需自评待办':data.q3t}}</td>\r\n            <td style=\"width:221px\">{{data.q4t}}</td>\r\n          </tr>\r\n        </tbody>\r\n      </nz-table>\r\n    </div>\r\n    <div class=\"navbar navbar-expand-md bg-white navbar-dark\">\r\n      <span style=\"color:white\">别扯了,这是底线</span>\r\n    </div>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/target/target-self-todo/target-self-todo.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/target/target-self-todo/target-self-todo.component.ts ***!
  \***********************************************************************/
/*! exports provided: TargetSelfTodoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetSelfTodoComponent", function() { return TargetSelfTodoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/comps/MyComponent */ "./src/app/comps/MyComponent.ts");
/* harmony import */ var src_app_datasource_TargetDataSource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/datasource/TargetDataSource */ "./src/app/datasource/TargetDataSource.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_target_service_target_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/target-service/target.service */ "./src/app/target-service/target.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _entity_EvalVirtProc__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../entity/EvalVirtProc */ "./src/app/entity/EvalVirtProc.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var TargetSelfTodoComponent = /** @class */ (function (_super) {
    __extends(TargetSelfTodoComponent, _super);
    // 注入路由信息,以及评价的服务
    function TargetSelfTodoComponent(routerInfo, targetService, fb, modalService, msg, datePipe) {
        var _this = _super.call(this, routerInfo, targetService, fb, modalService, msg) || this;
        _this.routerInfo = routerInfo;
        _this.targetService = targetService;
        _this.fb = fb;
        _this.modalService = modalService;
        _this.msg = msg;
        _this.datePipe = datePipe;
        _this.year = '2018';
        _this.allChecked = false;
        _this.dataSet = [];
        //全选样式 控制
        _this.indeterminate = false;
        return _this;
    }
    /**
       * 根据年份获取数据
       * @param result
       */
    TargetSelfTodoComponent.prototype.onChange = function (result) {
        this.year = result.getFullYear() + '';
        this.loadData();
        console.log('onChange: ', this.year);
    };
    TargetSelfTodoComponent.prototype.refreshStatus = function () {
        // @ts-ignore
        var allChecked = this.dataSource.dataStatus.anyData.every(function (value) { return value.checked === true; });
        // @ts-ignore
        var allUnChecked = this.dataSource.dataStatus.anyData.every(function (value) { return !value.checked; });
        this.allChecked = allChecked;
        this.indeterminate = (!allChecked) && (!allUnChecked);
    };
    TargetSelfTodoComponent.prototype.checkAll = function (value) {
        // @ts-ignore
        this.dataSource.dataStatus.anyData.forEach(function (data) {
            if (null != data.q1t && null != data.q2t && null != data.q3t && null != data.q4t) {
            }
            else {
                data.checked = value;
            }
        });
        this.refreshStatus();
    };
    TargetSelfTodoComponent.prototype.loadData = function () {
        // 加载表格数据 ，使用前端分页就好
        // @ts-ignore
        this.dataSource.loadTodoList(this.year);
        // @ts-ignore
        // TODO
    };
    TargetSelfTodoComponent.prototype.initSearchFields = function () {
        this.searchFields.set('employeeCode', '员工编号');
        this.searchFields.set('employeeName', '员工姓名');
    };
    TargetSelfTodoComponent.prototype.ngOnInit = function () {
        // 初始化搜索界面
        _super.prototype.initSearch.call(this);
        // 初始化数据表
        _super.prototype.initTable.call(this, new src_app_datasource_TargetDataSource__WEBPACK_IMPORTED_MODULE_2__["TargetDataSource"](this.targetService));
        //初始化刷新全选状态
        this.refreshStatus();
    };
    /**
     * 推送代办
     * @param label
     */
    TargetSelfTodoComponent.prototype.selectTest = function (label) {
        var _this = this;
        var params = new Array();
        // @ts-ignore
        this.dataSource.getEnddate(label.substring(2)).subscribe(function (datas) {
            // ******
            // @ts-ignore
            _this.dataSource.dataStatus.anyData.forEach(function (data) {
                if (data.checked) {
                    if (label.substring(2) == '1' || label.substring(2) == '3' && data.tarTemplate == '2') {
                    }
                    else {
                        var entity = new _entity_EvalVirtProc__WEBPACK_IMPORTED_MODULE_8__["EvalVirtProc"]();
                        entity.empCode = data.employeeCode;
                        if (data.tarTemplate == 1) {
                            entity.enddate = datas.type1;
                        }
                        else {
                            entity.enddate = datas.type2;
                        }
                        entity.date = _this.year;
                        entity.label = label;
                        params.push(entity);
                    }
                }
            });
            if (params.length < 1) {
                _this.warning();
                return;
            }
            // @ts-ignore
            _this.dataSource.insertBpmVirtRecord(JSON.stringify(params)).subscribe(function (data) {
                if (data > 0) {
                    _this.success();
                    _this.loadData();
                }
            });
            // ***
        });
    };
    /**
     * 删除待办
     * @param code
     */
    TargetSelfTodoComponent.prototype.deleteTest = function (code) {
        var _this = this;
        var param = new Array();
        // @ts-ignore
        this.dataSource.dataStatus.anyData.forEach(function (data) {
            if (data.checked) {
                var parr = [data.instanceid1, data.instanceid2, data.instanceid3, data.instanceid4];
                var entrys = new TempEntity();
                entrys.setEmployeeCode(data.employeeCode);
                entrys.setCode(_this.year + '年第' + code.substring(0, 1) + '季度自评');
                // @ts-ignore
                param.push(entrys);
            }
        });
        if (param.length < 1) {
            this.warning();
            return;
        }
        this.showConfirm(code, param);
    };
    TargetSelfTodoComponent.prototype.warning = function () {
        this.modalService.warning({
            nzTitle: '信息提示',
            nzContent: '请选择想要操作的数据(注;类型为2的用户只有二、四季度的自评）'
        });
    };
    // style
    TargetSelfTodoComponent.prototype.success = function () {
        this.modalService.success({
            nzTitle: '成功！',
            nzContent: '所选人员代办推送成功'
        });
    };
    // style
    TargetSelfTodoComponent.prototype.delete = function () {
        this.modalService.success({
            nzTitle: '成功！',
            nzContent: '所选人员代办删除成功'
        });
    };
    TargetSelfTodoComponent.prototype.showConfirm = function (code, param) {
        var _this = this;
        this.modalService.confirm({
            nzTitle: '<i>删除确认</i>',
            nzContent: '<b>你确认要删除所选待办?</b>',
            nzOnOk: function () {
                // @ts-ignore
                _this.dataSource.deleteVirtRecord(JSON.stringify(param)).subscribe(function (data) {
                    if (data > 0) {
                        _this.delete();
                        _this.loadData();
                    }
                });
            }
        });
    };
    TargetSelfTodoComponent.prototype.resetForm = function () {
        this.employeeName = '';
        this.employeeCode = '';
    };
    // query，按条件检索
    TargetSelfTodoComponent.prototype.selectByCondition = function () {
        var _this = this;
        if (!this.flag) {
            this.tableSource = this.dataSource.dataStatus.anyData;
            this.flag = true;
        }
        else {
            this.dataSource.dataStatus.anyData = this.tableSource;
        }
        // @ts-ignore
        this.dataSource.dataStatus.anyData = this.dataSource.dataStatus.anyData.filter(function (item) {
            if (_this.employeeName != '' && _this.employeeCode != '' && _this.employeeCode != null && _this.employeeName != null) {
                if ((item.employeeName.indexOf(_this.employeeName) > -1) && (item.employeeCode.indexOf(_this.employeeCode) > -1)) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else if (_this.employeeName != '' && _this.employeeName != null) {
                if (item.employeeName.indexOf(_this.employeeName) > -1) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else if (_this.employeeCode != '' && _this.employeeCode != null) {
                if (item.employeeCode.indexOf(_this.employeeCode) > -1) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return true;
            }
        });
        return null;
    };
    /**
     * 键盘回车提交事件
     * @param event
     */
    TargetSelfTodoComponent.prototype.search = function (event) {
        if (event.keyCode == 13) {
            this.selectByCondition();
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], TargetSelfTodoComponent.prototype, "year", void 0);
    TargetSelfTodoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-target-self-todo',
            template: __webpack_require__(/*! ./target-self-todo.component.html */ "./src/app/target/target-self-todo/target-self-todo.component.html"),
            styles: [__webpack_require__(/*! ./target-self-todo.component.css */ "./src/app/target/target-self-todo/target-self-todo.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], src_app_target_service_target_service__WEBPACK_IMPORTED_MODULE_4__["TargetService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["NzModalService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["NzMessageService"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["DatePipe"]])
    ], TargetSelfTodoComponent);
    return TargetSelfTodoComponent;
}(src_app_comps_MyComponent__WEBPACK_IMPORTED_MODULE_1__["MyComponent"]));

var TempEntity = /** @class */ (function () {
    function TempEntity() {
    }
    TempEntity.prototype.getEmployeeCode = function () {
        return this.employeeCode;
    };
    TempEntity.prototype.setEmployeeCode = function (instanceId) {
        this.employeeCode = instanceId;
    };
    TempEntity.prototype.getCode = function () {
        return this.code;
    };
    TempEntity.prototype.setCode = function (code) {
        this.code = code;
    };
    return TempEntity;
}());


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\AngularProjects\maintain-platform\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map